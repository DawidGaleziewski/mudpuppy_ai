# MudPuppy rust logo — web assets

Approved richer-rust and mud version with clean, bright eyes, BEFORE the added teal LEDs. No lettering.

- PNG widths: 128, 256, 512 and 1024 px, preserving aspect ratio.
- Master: 1394 × 1128 px. All sized PNG exports are downscaled from this source.
- mudpuppy-rust.svg: actual vector paths, no embedded raster. A 24-colour trace at 697 × 564 preserves the rust texture; it is deliberately more detailed/heavier than a clean circle-based SVG. Minor colour and fine-detail simplification compared with the PNG. PNG is recommended for ordinary webpage use; SVG is the editable vector rendition.
- Dark background retained to preserve the selected design. These are not transparent assets.
- Favicon: head-and-gills crop of the same artwork, for small-size recognition.
- favicon.ico contains 16, 32, 48 and 64 px images.
- Additional PNG icons: 16, 32, 48, 64, 192 and 512 px; Apple touch icon: 180 px.

Copy the files to your public directory, then add:

```html
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
```

For the logo:

```html
<img src="/mudpuppy-rust-256.png"
     srcset="/mudpuppy-rust-256.png 1x, /mudpuppy-rust-512.png 2x"
     width="256" height="207" alt="MudPuppy">
```
