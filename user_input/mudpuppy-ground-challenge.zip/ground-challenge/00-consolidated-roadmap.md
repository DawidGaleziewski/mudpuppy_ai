# MudPuppy — Ground Challenge: Consolidated Roadmap

> **One document for the whole `ground-challenge/` set.** It merges the eleven source documents
> (README, `01`–`08`, the anonymisation note and the CHANGELOG through *update 4*, 2026-10-15) into a
> single plan for hardening MudPuppy: an executive summary, one priority order, the phased roadmap
> with the later field findings folded in, every decision still open, the full reference catalogue,
> a traceability matrix and a list of inconsistencies in the source set.
>
> **Reading the markers.** Items marked **➕** were *added in this consolidation* — they come from
> findings recorded after `06-roadmap.md` was written (SQ-7, SQ-8, GC-20…GC-22, D-8, D-9, group G)
> and had no roadmap slot; their effort is an estimate made here. Paragraphs headed
> *Consolidation note* are analysis, not source material. Everything else restates the source.
>
> **Anonymised** under the same contract as the source (§9): **Portal-X** (the legacy insurer
> portal), the **SSO/OAuth identity provider**, the **corporate proxy**, the **TLS-inspection CA**.
> No portal names, hosts, URLs, User-Agents, personas, credentials, CA paths or copied evidence.

## Contents

1. [Executive summary](#1-executive-summary)
2. [Unified priority order](#2-unified-priority-order)
3. [Recommended first sprint](#3-recommended-first-sprint)
4. [Roadmap — Phases 0–5](#4-roadmap--phases-05)
5. [Decisions to take before building (D-1 … D-9)](#5-decisions-to-take-before-building-d-1--d-9)
6. [Reference catalogue](#6-reference-catalogue)
   - 6.1 [Core changes (C-1 … C-10)](#61-core-changes-c-1--c-10)
   - 6.2 [Hook patterns (H-1 … H-4)](#62-hook-patterns-h-1--h-4)
   - 6.3 [Trace-driver pattern](#63-trace-driver-pattern-forcing-a-form-process-to-completion)
   - 6.4 [Field issues (GC-01 … GC-22)](#64-field-issues-gc-01--gc-22)
   - 6.5 [Scan-quality findings (SQ-1 … SQ-8)](#65-scan-quality-findings-sq-1--sq-8)
   - 6.6 [The documentation pipeline and the two "processes"](#66-the-documentation-pipeline-and-the-two-processes)
   - 6.7 [Proving-ground candidates (groups A–G)](#67-proving-ground-candidates-groups-ag)
7. [Traceability matrix](#7-traceability-matrix)
8. [Consistency notes on the source set](#8-consistency-notes-on-the-source-set)
9. [Anonymisation contract](#9-anonymisation-contract)
10. [Change history](#10-change-history)
- [Appendix — source file index](#appendix--source-file-index)

---

## 1. Executive summary

**What this is.** MudPuppy was run against a real, corporate, login-gated legacy insurer portal
(Portal-X) through a downstream fork that was patched live during a client engagement. The fork's
patches, a separate issue log and later field diagnoses were distilled into anonymised lessons. This
document turns all of them into one plan for MudPuppy proper.

**Inventory.** 10 core changes · 4 hook patterns (+ 1 tooling gotcha) · 1 trace-driver pattern ·
22 field issues · 8 scan-quality findings · 9 open design decisions · 6 roadmap phases ·
35 proving-ground scenarios in 7 groups.

### Six themes

| # | Theme | What goes wrong | Where it is fixed |
| --- | --- | --- | --- |
| 1 | **Corporate environment** | Proxy-only reachability, IP allowlist, TLS inspection, a WAF rejecting non-browser User-Agents, a missing native toolchain — and errors that don't point at the cause. | Phase 3 (doctor + `network.*` config) |
| 2 | **Auth & redirect chains** | The SPA login renders late at a polite rate; a single-shot success check runs mid-redirect on the IdP host; ambiguous is treated as failed, which locks the run out. | D-2, Phase 5 |
| 3 | **Frontier waste** | Hidden/unactionable items are issued, refused and re-issued; runs wedge in `running`; 148 of 165 turns in one map were refusal churn; ~60 credits per small map. | Phase 4 |
| 4 | **Hidden or late content** | Collapsed accordions, cookie-gated lists, late-mounting micro-frontends and blocked stylesheets produce hollow or unstyled evidence. | H-1…H-3, Phases 3–5 |
| 5 | **Form processes never finish** | `map` mode stops at the first irreversible action, and asking the agent to "just finish the form" is unreliable. | Phase 2 (trace driver) |
| 6 | **Documentation pipeline** | The `narrow` (reconciliation) step was skipped, so the BA documented raw runs: duplicates, one-step stubs, thin evidence; two unlinked layers are both called "processes". | ➕ Phase 5 pipeline-integrity items, D-8, D-9 |

Cutting across all six: **environment-model hazards** — stray stores, MCP servers silently on the
wrong environment, production gating by hostname regex (C-8, C-9, GC-22, D-1).

### The five things that matter most

1. **Reconcile before documenting (SQ-8).** The thin and duplicate process docs are caused by a
   skipped `narrow` step, not by a BA defect. Operationally: run `narrow`, then the BA. In the
   product: make `document` refuse or warn on un-narrowed input (D-8).
2. **Stop the frontier bleeding (SQ-3, GC-15/16/18).** Don't issue hidden items, put `next` in every
   refusal, retire unactionable items so `finish_run` can complete.
3. **Land the Phase 0 core fixes (C-1…C-7, C-10, GC-14).** Low risk; unblocks one-big-form legacy
   portals and framework-bound SPA/SSO logins.
4. **Build the trace driver (Phase 2).** The single highest-value feature for "finish a form
   process" — and it should tag its runs so `narrow` can group them automatically.
5. **No silent environment fallback (GC-22).** A cheap guard against writing to the wrong store,
   ahead of the full environment-model redesign (C-9, D-1).

**Success criterion for the whole effort (D-7):** the next client fork needs **zero local core
patches** — only config and hooks.

---

## 2. Unified priority order

*Consolidation note.* The source has two orderings that don't fully agree. `05` ranks scan-quality
fixes with SQ-8 first; `06` orders phases by dependency (0 → 1 → 2 …) and its suggested first sprint
predates SQ-8. The merged order below takes urgent-and-cheap work first, then follows dependencies.

| Rank | Work | Ids | Why at this rank | Phase |
| --- | --- | --- | --- | --- |
| 1 | Run `narrow` on the existing store, then re-run the BA on the reconciled processes and key the docs onto `PRC-*` | SQ-8, D-9 | Root cause of the duplicate/thin docs; needs no code | Operational |
| 2 | `document` warns/blocks on un-narrowed input; a skipped `narrow` is visible in the dashboard | D-8 | Prevents recurrence; no dependencies | ➕ 5, pulled forward |
| 3 | `next` in refusals; retire unactionable items; don't issue hidden items | GC-15/16/18, SQ-3 | Stops wedged runs and the cost bleed | 4, pulled forward |
| 4 | Core fixes | C-1…C-7, C-10, GC-14 | Unblocks legacy + SPA portals at low risk | 0 |
| 5 | No silent env fallback; current env shown in every result | GC-22 | Cheap guard against wrong-store writes | ➕ 1, pulled forward |
| 6 | Content-ready wait before capture; asset-health check | SQ-4, H-3, GC-13 | Stops junk evidence at the source | 4 / 3 |
| 7 | Dedup shared nav; stable text locators | SQ-2, C-3 | Clean, de-duplicated inputs for the BA | 4 / 0 |
| 8 | Trace driver | `03`, SQ-6 | Gives the BA real process evidence | 2 |
| 9 | BA quality gate, run selection by richness, per-step citation | SQ-6, SQ-7, GC-20/21, D-4 | Raises the bar once inputs are clean | 5 |
| 10 | Resume mapping from a known node | SQ-5, D-5 | Usability for partial re-scans | 4 |
| 11 | Environment model done right | C-8/9, D-1, SQ-1 | Correct prod gating; ends store scatter | 1 |
| 12 | Doctor + agnostic network config | GC-02…07, GC-12/13 | Corporate first-start pain; a parallel track | 3 |
| 13 | Auth redesign (condition waits, `pending`, transit zones) | GC-08/09/11, D-2 | Design-heavy: decide early, build later | 5 |

---

## 3. Recommended first sprint

**Source recommendation (`06`):** Phase 0 in full, plus the two Phase 4 quick wins (`next` in
refusals; retire unactionable items) to stop wedged runs immediately — then Phase 2.

**Consolidated recommendation** (the source plan, extended with the later findings):

**Operational — no code**
- Start the chat orchestrator service; run `narrow` on the engagement store and accept the
  groupings, so each journey becomes one `ba_process` with happy-path and validation-error variants
  as branches. Grouping writes to the store; it is revision-reversible.
- Re-run the BA over the reconciled processes, citing one screen region per step and per variant
  state, with the docs keyed onto the reconciled `PRC-*` model.
- Align `PATHFINDER_ENV` in `mcp.json` with the working environment and stop stray MCP server
  processes from other checkouts.

**Build**
- Phase 0 in full (C-1…C-7, C-10, GC-14).
- Phase 4 quick wins: `next` in refusal results; retire unactionable items (e.g. `javascript:`
  popups) so `finish_run` completes with a documented remainder.
- ➕ D-8 guard: `document` warns when raw runs exist but `narrow` produced no grouped processes.
- ➕ GC-22 guard: the MCP server refuses to start with an unset/ambiguous environment, and every
  result shows the current environment.
- A proving-ground gate case for each of the above (groups A and C, `UNSET_ENV` from group E, and a
  new un-narrowed-store fixture for group G — see §7).

**Decide** — so later phases aren't blocked: **D-1** (environment model), **D-2** (wait and auth
model; a spec of its own), **D-8** (enforcing `narrow`), **D-9** (naming and cross-linking).

**Next sprint:** Phase 2 (trace driver), with run tagging so its variants group automatically.

---

## 4. Roadmap — Phases 0–5

> A proposal distilled from the field work; it does not replace `roadmap.md` at the repo root. Fold
> the accepted items into that roadmap with proper spec ids. Effort is S / M / L. The *Source* column
> cites the lesson ids (`C-*` core change, `GC-*` field issue, `SQ-*` finding, `H-*` hook pattern,
> `D-*` decision). Phases are roughly independent except where noted.

### Dependencies

```mermaid
flowchart LR
  P0["Phase 0 · Core fixes"] --> P2["Phase 2 · Trace driver"]
  P0 --> P1["Phase 1 · Environment model"]
  P1 --> SQ1["SQ-1 store scatter resolved"]
  P2 --> P5["Phase 5 · Auth & BA quality"]
  P4["Phase 4 · Frontier & resume"] --> P5
  P3["Phase 3 · Doctor & network"] -. "independent; enables corporate portals" .-> P5
```

Phase 2 needs C-5, C-6 and C-7 from Phase 0. Phase 5 needs Phase 4's clean inputs (and reuses its
wait primitive — see the Phase 4 note). Phase 3 can run in parallel at any time. ➕ The
pipeline-integrity items in Phase 5 depend on nothing and can ship in sprint 1.

### Phase 0 — Land the clearly-correct core fixes · effort M

Bring in the fixes that are correct as-is and unblock whole classes of portals.

| Item | Source | Effort | Acceptance |
| --- | --- | --- | --- |
| Scope the 403/429 hard-stop to the main-frame document | C-1 | S | A background XHR 403 does not stop the run; a 403 *page* still does. Unit + proving-ground case. |
| Anchor vs form-POST classification (`tag` field) | C-2 | M | On a one-big-`<form>` legacy page, navigation tiles classify `read` and a read-only run clicks them. Gate case. |
| Anchor text-first locator in SPAs | C-3 | S | A re-rendering list tile is relocated by text after re-render; no `click_failed`. |
| Wider actionability budget for role-less tiles | C-4 | S | A tile that settles in 6–10 s is clicked, not refused. |
| `selectOption` label fallback | C-5 | S | A `<select>` option is chosen by its visible label. |
| Framework-bound login fill (`enterBound`) | C-6 | S | A data-bound login form submits; the model receives the value. Proving-ground SPA-login case. |
| Non-http href guard (`isHttpUrl`) | C-7 | S | A `javascript:`/`mailto:` href does not crash `act`. Unit. |
| `api_endpoint` record kind + element `behaviour` | C-10 | M | The BA can create an `api_endpoint` record from a network shape; export renders it. Schema + render tests. |
| Multi-locale submit keyword dictionary (DE) | GC-14 | S | A German "Senden" link classifies as a submit; a read persona does not click it. |

### Phase 1 — Environment model done right (not re-hardcoded) · effort M · ⚠️ supersedes C-9

| Item | Source | Effort | Acceptance |
| --- | --- | --- | --- |
| Freeform environment label + per-env `production: true\|false` | C-9, GC-01, D-1 | M | A portal can declare any env name and flag it non-production; adding a tier needs no code change. |
| Single source of truth for environments (collapse the duplicated enum) | C-9 | M | One definition; config, vault, store and mcp import it. |
| Production-address guard keys off the declared flag (or an explicit host allowlist), not a hostname regex | GC-01, D-1 | M | A dev host that doesn't match the old regex is *not* gated as production when flagged non-prod. |
| `KNOWN_ENVIRONMENTS`-style guard against stray stores, derived from the declared envs | C-8, SQ-1 | S | An undeclared slug is rejected with a helpful message; readers of existing files still open them. |
| Mutation tests around env/run routing and prod gating | GC (to-improve) | M | A mutant that inverts prod gating or drops an env label is killed. |
| ➕ No silent env fallback: the MCP server refuses to start (or demands an explicit env) when `PATHFINDER_ENV` is unset or ambiguous | GC-22 | S | `UNSET_ENV` gate: the server refuses to start. |
| ➕ Env-agreement check across the MCP server, dashboard and chat orchestrator | GC-22 | M | `ENV_MISMATCH` gate: a loud warning at start-up. |
| ➕ Per-data-dir PID/lock file that detects stray MCP servers from another checkout | GC-22 | S | `STRAY_MCP_PROCESS` gate: the second instance is warned about. |
| ➕ Current env shown in every MCP result and in the dashboard header | GC-22 | S | Every result and page header carries the env label. |
| ➕ Robots/compliance strictness tied to `production: false` | GC-01 | S | `ROBOTS=deny` on a non-prod tier does not refuse navigations. |

*Consolidation note.* The GC-22 guards need no redesign — the "refuse to start" and "show the env"
items can ship in sprint 1, before the freeform model lands.

### Phase 2 — Trace driver: force form processes to completion · effort L · depends on Phase 0 (C-5/6/7)

The highest-value feature for "finish a form process" (full pattern in §6.3).

| Item | Source | Effort | Acceptance |
| --- | --- | --- | --- |
| `traces.yaml` schema in `config` (validated), with `to_be_discovered` stubs | `03` | M | A bad traces file is rejected naming the problem; stubs are skipped. |
| `pnpm trace <portal> <id\|all> <persona> --env <env> [--variant]` driving `mode:"trace"` | `03` | L | Headless, bounded; one `processes` row + ordered `process_steps` per variant. |
| Variants: happy-path / validation-error / loading | `03` | M | The validation variant records its error message(s) as rule candidates; loading state captured or honestly "none". |
| Privilege decides submit vs boundary | `03` | S | A high-privilege persona executes the submit and records the result; a lower ceiling stops at `boundary_reached`. |
| Synthetic-data enforcement on scrub portals | `03` | S | Suspected PII in a trace value is rejected. |
| Dashboard Process tab renders each variant as a flowchart with the start node marked | `03` | M | Each variant visible as `flowchart TD` with a `start([...])`. |
| BA follow-up loop: named process → stub → map discovers → steps filled → driver → use-case | `03`, SQ-6 | M | The map → document → trace → document loop runs end-to-end on the reference portal. |
| ➕ Trace runs carry the trace id and variant id, so `narrow` auto-suggests (or auto-creates) one `ba_process` with the variants as branches | `03`, SQ-8, D-8 | M | Driving all variants of one trace yields a single grouping suggestion with N variant branches. |
| ➕ Reach UI-only processes by navigation from a known node, not only by deep-linking `start_url`; exempt the login redirect from `only_paths` | SQ-5, SQ-7, D-5 | M | `DEEPLINK_BLOCKED` gate: real steps captured, no error-page stub. |

*Consolidation note.* The driver emits one `processes` row per variant — exactly the raw runs that
`narrow` must reconcile. Without run tagging and the D-8 guard, Phase 2 would multiply the SQ-8
problem rather than solve SQ-6.

### Phase 3 — First-start "doctor" + agnostic network config · effort L

Removes most corporate-environment first-day pain. Independent of the other phases.

| Item | Source | Effort | Acceptance |
| --- | --- | --- | --- |
| `network.proxy { server, bypass, enabled }` honoured by the request gate | GC-03/05 | M | A proxy-only portal is reachable; bypass hosts go direct. Proving-ground allowlist case. |
| Per-host routing (proxy vs direct) + corporate CA trust (`network.ca_certificates`) | GC-12 | M | Portal host via proxy, asset host direct; a TLS-inspected direct host trusts the configured CA. |
| Asset-health check (`network.asset_check`) + optional recapture | GC-13, SQ-4 | M | A blocked key asset emits a warning + `render_warnings`; the screenshot is recaptured once assets load. |
| Doctor registry (id, applies_when, depends_on, probe, signature, fix, inputs) | GC-02/04/06/07 | L | New checks/fixes are added via the registry with no core change; the first run prints a diagnosis. |
| WAF-UA + native-toolchain + PAC checks as registry entries | GC-04/06/07 | M | Each prints the cause and the one-line fix. |
| ➕ IP-allowlist (`net.ip-allowlist`) and TLS-inspection (`net.tls-inspection`) checks as registry entries | GC-05, GC-12 | S | An allowlist 403 points at the proxy; a TLS-inspected host points at the CA option. |

### Phase 4 — Frontier efficiency & resume · effort L · biggest cost/quality win

| Item | Source | Effort | Acceptance |
| --- | --- | --- | --- |
| Don't issue hidden/unclickable items | GC-16, SQ-3 | M | Hidden items never reach the agent; the refusal rate drops sharply (measured on a gate). |
| Carry `next` in refusal results | GC-16 | S | A refusal advances to the next frontier item in the same turn. |
| Retire an unactionable item (record, don't re-queue) so `finish_run` can complete | GC-15/18, SQ-3 | M | A `javascript:` popup item is recorded + retired; the run completes with a documented remainder. |
| Server-side batch drain for read-only map runs | GC-16 | L | A read-only map drains many read items per server round-trip; turns per state fall. |
| Dedup shared navigation actions across states | GC-16, SQ-2 | M | The global nav isn't re-walked on every page. |
| Cost per run in the dashboard (populate `agent_turns`) | GC-16 | S | Each run shows its turn/credit cost. |
| Resume map from a known node (seed the frontier from a state's unexplored actions; reuse states by fingerprint) | SQ-5, D-5 | L | Mapping a subtree from a chosen node continues the existing graph instead of starting fresh. |
| Content-ready wait before evidence capture | SQ-4, H-3 | M | Screenshots/snapshots are taken only after a content-ready signal, not just network idle. |
| ➕ "Turns per new state" and refusal rate as tracked metrics with targets, plus a budget alert | D-6, `08` group C | S | Gate group C asserts both are under target. |
| ➕ Duplicate-screen warning when two states share a route template and near-identical layout; run the existing `stability` tool between runs | SQ-2 | M | A warning is raised on a fixture with a re-keyed duplicate screen. |

*Consolidation note — two dependency inversions to resolve here.*
(1) SQ-4 says the content-ready wait is "the same condition-based wait as H-3/D-2", but the general
condition + deadline wait sits in Phase 5. Build the wait primitive **once, in Phase 4**, with
content-ready capture as its first consumer; Phase 5 then reuses it for login, navigate and act.
(2) Resume-from-node (D-5) needs the login redirect exempted from `only_paths`, which D-5 ties to the
Phase 5 transit zones. Ship a simple exemption in Phase 4 (the portal's declared login hosts/paths)
and generalise it to transit zones in Phase 5.

### Phase 5 — Auth/transit zones & BA quality · effort L · depends on Phase 4

| Item | Source | Effort | Acceptance |
| --- | --- | --- | --- |
| One condition-based wait with a progress-extending deadline (login, navigate, act) | GC-08/09, D-2 | L | A slow multi-hop login succeeds; the wait extends while there is progress. |
| `pending` outcome (not `failed`) for ambiguous auth | GC-09, D-2 | M | An in-progress redirect chain yields `pending`, not a lockout. |
| Per-portal transit zones (poll, don't record intermediate hops) | GC-09, D-2 | M | Cross-host login hops aren't recorded as states; the final landing is. |
| Login success/failure markers + late-error handling | GC-09/11 | M | A transient IdP error is distinguished from `control_not_found`; evidence is captured after the error renders. |
| Expand-collapsed + pre-run cookie as declarative config | H-1/H-2, GC-18/19 | M | Collapsed content revealed (hidden-only, submit-suppressed); flag cookie seeded. |
| Documentation quality gate | SQ-6, D-4 | M | A doc set with screens but zero requirements/rules, or duplicate screens sharing a route template, is flagged. |
| Credential bulk import | GC-17 | M | Many personas' credentials imported from a refs file; no plaintext on argv. |
| Hook-authoring docs incl. the `__name`/esbuild gotcha (or a `NAME_SHIM`) | H-* | S | In-page hooks documented; the gotcha has a documented remedy. |
| ➕ **Pipeline integrity:** `document` warns/blocks when raw runs exist and `narrow` produced zero grouped processes | SQ-8, D-8 | S | Un-narrowed fixture → `document` refuses or warns loudly. |
| ➕ A skipped `narrow` is visible in the pipeline status and dashboard | SQ-8, D-8 | S | The dashboard shows `narrow` as skipped, not a silent default. |
| ➕ Groupings auto-suggested as part of the standard flow; the human accepts/adjusts | D-8 | M | After trace runs, suggestions appear without a manual invoke. |
| ➕ The orchestrator-running prerequisite and the store mutation are surfaced in automated runs | D-8 | S | An automated run fails fast with a clear message if the orchestrator is down. |
| ➕ Run selection by evidence richness; interrupted runs allowed with an honest partial `observed_extent`; step/screenshot counts in `list_runs` | GC-20, SQ-7 | M | `RICH_INTERRUPTED_RUN` gate: the interrupted 12-step run is the one documented. |
| ➕ Data-hygiene pass: de-dup or mark-usable near-duplicate variant runs | SQ-7, SQ-2 | M | `DUP_VARIANT_RUNS` gate: the rich run wins. |
| ➕ Citation check: one `screen_region` per step and per variant state; tightened BA guidance | GC-21 | S | `MULTISTEP_PROCESS` gate: steps/states without a cited region are flagged. |
| ➕ Rename the two "processes" in the UI (e.g. "Process model" vs "Process documentation") | D-9 | S | No two navigation labels both say "Processes". |
| ➕ 1:1 cross-link `doc_record` (process / use_case) ↔ `ba_process`, shown on both pages | D-9 | M | Every `PROC-*`/`UC-*` links to a `PRC-*` and back. |
| ➕ `document` runs over the reconciled `ba_processes`, so `PROC-*` always maps to a `PRC-*` | D-9, D-8 | M | No orphan `PROC-*` after a document run. |
| ➕ Redact credential *values*, not an id that merely matches one | GC-10 | S | `PERSONA_ID_EQUALS_LOGIN` gate: the persona id stays readable. |

*Consolidation note.* Only the auth and quality-gate items need Phase 4's clean inputs. The
pipeline-integrity guard (first two ➕ rows) depends on nothing and belongs in sprint 1.

---

## 5. Decisions to take before building (D-1 … D-9)

| Id | Question | Recommendation | Blocks |
| --- | --- | --- | --- |
| D-1 | How is an environment declared, and how is "is this production?" decided? | Freeform label + explicit `production` flag, with a safety rail for production-looking hosts | Phase 1 |
| D-2 | How do we wait, and when is login "done"? | One condition + deadline wait, a `pending` outcome, transit zones, rate limits split by request class | Phase 5 (decide early) |
| D-3 | Hooks vs declarative config — where is the line? | Common cases as config, hooks as the escape hatch, a small stable hook API | Phase 5 |
| D-4 | What is the BA quality bar, and should it gate? | Fix inputs first; a *flagging* gate, promoted to hard-fail once stable | Phase 5 |
| D-5 | What does "scan from a point" mean for maps? | Explicit resume-from-node mode; auto-exempt the login/transit zone from `only_paths` | Phase 4 |
| D-6 | How do we make a map cheap and visible? | All of: batch drain, never issue hidden items, dedup nav, cost per run with a budget alert | Phase 4 |
| D-7 | How do field fixes flow back without leaking client data? | This folder + the skill; success = zero local core patches | Process |
| D-8 | Who owns reconciliation, and should `document` refuse un-narrowed input? | Keep it in `narrow`; guard `document`; auto-suggest groupings | ➕ Phase 5 / sprint 1 |
| D-9 | Two layers are both called "processes" and aren't cross-linked — fix how? | Keep both layers; rename, cross-link 1:1, document over the reconciled model | ➕ Phase 5 |

### D-1 — Environment model: enum, freeform, or hybrid?

**Context.** The enum `production | staging | sandbox` didn't fit the client's tiers; the fork
re-hardcoded a different triple across six-plus files (C-9). The production-address guard uses a
hostname regex of known non-prod labels, which mis-gated a dev host.

- **Option A — keep an enum, add client tiers.** Simple, but every client needs a code change and the
  duplication stays.
- **Option B — freeform label + explicit `production: true|false` per env.** The guard keys off the
  declared flag (plus an optional explicit host allowlist), not a regex; one source of truth; a tier
  is added with config only.
- **Option C — hybrid.** Freeform label, but a small reserved set (`production`) still forces the
  strict gate regardless of the flag.

**Recommendation:** B with C's safety rail — a production-looking address combined with
`production: false` triggers a loud confirmation, not a silent pass. Add mutation tests on the
gating. GC-22 adds the operational half: no silent default env. → Phase 1.

### D-2 — Auth & long redirect chains: how do we wait and when is login "done"?

**Context.** The biggest field pain: fixed timeouts that ignore the limiter, single-shot success
checks, multi-hop cross-host redirects, and "ambiguous = failed = lockout" (GC-08/09/11).

1. **Wait model** — one mechanism for login/navigate/act that waits on conditions with a deadline
   that extends while there is progress, vs per-operation fixed timeouts.
2. **Outcome model** — a `pending` outcome distinct from `failed`, so an in-progress chain isn't a
   lockout.
3. **Transit zones** — per-portal hosts/paths where the crawler polls but doesn't record
   intermediate (IdP) hops, recording only the landing.
4. **Rate limits** — separate budgets for the main document, static assets and third parties, since
   the polite rate starved the SPA login form.

**Recommendation:** design one condition + deadline wait, add `pending`, define transit zones in
the portal file, and split the rate limit by request class. This is a spec on its own; decide early
because it touches login, navigate and act. → Phase 5 (wait primitive built in Phase 4 — see the
Phase 4 note).

### D-3 — Hooks vs declarative config: where is the line?

**Context.** The fork implemented the pre-run cookie, expand-collapsed, late-mount wait and stack
detection as hooks; the issue log shipped some as declarative config (`cookies:`,
`expand_toggles:`, `login.wait`, `network.*`).

- **Config** fits the common, parameterisable cases: seed cookies, expand toggles, waits,
  proxy/CA/asset-check.
- **Hooks** fit the bespoke 10%: a page-specific classifier, an unusual DOM dance.

**Recommendation:** ship the common four as declarative config with hooks as the escape hatch.
Define a small, stable hook API (lifecycle points, `inPage`, `cookies`, `log`, `waitFor`) and
document the `__name`/esbuild in-page gotcha (or add a `NAME_SHIM`). → Phase 5.

### D-4 — What is the BA quality bar, and should it gate?

**Context.** Documentation was thin — screens recorded twice, no requirements or business rules
(SQ-6).

1. What is the minimum for a documented portal? (e.g. every capability has ≥ 1 requirement; every
   form process has a use case with main + exception flows; validation messages become business
   rules.)
2. Should a quality gate *fail* an export below the bar, or just *flag* it?
3. How much is input quality (dedup screens, process evidence) vs BA guidance?

**Recommendation:** fix inputs first (Phase 4), feed process evidence (Phase 2), then add a
*flagging* gate (not hard-fail) that lists gaps: screens without requirements, duplicate screens
sharing a route template, processes without exception flows. Promote to hard-fail once stable.
SQ-8 adds a precondition: `narrow` must have run (D-8). → Phase 5.

### D-5 — "Scan from a point": resume-mapping semantics

**Context.** `focus.start_url` exists, but a focused map re-discovers the subtree fresh, and
`focus.only_paths` fences out login hops (SQ-5).

1. Should a focused map attach to the existing graph — seed the frontier from a chosen state's
   unexplored outgoing actions and reuse recorded states by fingerprint?
2. How does `focus.only_paths` interact with a login redirect that must leave the allowed paths?
   (Auto-allow the login/transit hosts? A separate `auth_paths`?)

**Recommendation:** an explicit resume-from-node map mode (reuse states by fingerprint, expand only
the chosen node's unexplored frontier) and an automatic exemption of the portal's login/transit zone
from `only_paths`. Document the interaction. → Phase 4 + D-2.

### D-6 — Cost model: how do we make a map cheap and visible?

**Context.** ~60 credits per small map; 45% of a day's calls were in runs that never finished
(GC-16).

**Recommendation:** all of — server-side batch drain for read-only maps, never issue hidden items,
dedup shared nav, cost per run (`agent_turns`) in the dashboard with a budget alert. Treat "turns per
new state" as a tracked quality metric with a target, measured on a proving-ground gate. → Phase 4.

### D-7 — Downstream fork → upstream flow

**Context.** The client work lives in a fork that is regenerated on every update, so local patches
are overwritten; the issue log says "don't fix here, write an issue".

**Recommendation:** this `ground-challenge` folder + the skill (`.kiro/skills/ground-challenge/`)
is the mechanism — extract anonymised lessons on each engagement and land them upstream behind
declarative config + proving-ground gates, so the next fork needs zero local patches (only config +
hooks). Make "no local core patches, only config/hooks" the success criterion.

### D-8 — Enforce `narrow` before `document`

**Context** (SQ-8). The pipeline is **scan → map → narrow → document → amend**. Reconciliation is
the `narrow` step, owned by the chat orchestrator: it suggests groupings, and accepting one creates a
`ba_process` with happy-path/validation variants as branches. On the engagement `narrow` was skipped
(zero suggestions, grouped processes and variants), so the BA documented raw runs. The BA is not
supposed to merge runs; it documents a process.

1. Should `document` hard-refuse (or loudly warn) when raw trace runs exist but `narrow` produced
   zero grouped processes?
2. Should `narrow` be auto-run or auto-suggested in the standard flow, so a human only reviews and
   accepts groupings?
3. Does the BA ever get a limited reconciliation fallback ("these N runs are obviously one
   process"), or is that strictly the orchestrator's job?
4. The orchestrator must be running for grouping, and grouping is a (revision-reversible) store
   mutation — how is that surfaced and guarded in an automated run?

**Recommendation (to decide):** keep reconciliation in `narrow` (don't bloat the BA); add a pipeline
guard so `document` warns/blocks on un-narrowed input; show a skipped `narrow` plainly in the
dashboard; prefer auto-suggested groupings so the human step is accept/adjust. A BA fallback
reconciliation is a non-goal unless the guard proves insufficient. ➕ Pair with trace-run tagging
(Phase 2) so traced processes group themselves.

### D-9 — Two layers both called "processes"

**Context** (confirmed in the fork's dashboard code and schema). The **Processes tab** reads
`ba_processes` + `process_variants` — the reconciled model from `narrow` (keys `PRC-nnn`). **Docs →
"Processes and use cases"** reads `doc_records` of kind `process` (`PROC-nnn`) and `use_case`
(`UC-nnn`) — the written SRS from the BA `document` step. Same journeys, two id systems, two stores,
populated at different times, with no 1:1 cross-link (details in §6.6).

1. Should the UI stop calling both "processes" — e.g. Processes tab → "Process model" / "Journeys";
   Docs → "Process documentation"?
2. Should a `doc_record` process/use-case carry a reference to its `ba_process` (and vice versa)?
3. Should the pipeline order enforce that documentation is keyed onto the reconciled model
   (`document` only runs over `ba_processes`)?

**Recommendation (to decide):** keep the two layers — model vs SRS is a sound separation — but
(a) rename in the UI, (b) add a 1:1 cross-link surfaced on both pages, (c) make `document` run over
the reconciled model so the keys always correspond. The operational remedy offered on the
engagement — have the BA re-key its process docs onto the reconciled `ba_processes` — was recorded,
not applied.

---
## 6. Reference catalogue

The full detail behind the roadmap, condensed from the source files. Each entry ends with the
roadmap phase that carries it.

### 6.1 Core changes (C-1 … C-10)

Changes made to the crawler core while mapping Portal-X — the strongest candidates to bring back
into MudPuppy proper. ✅ = clearly correct, bring upstream as-is · ⚠️ = correct idea, but the fork
took a shortcut that should be done properly upstream.

**C-1 ✅ A 403/429 on a background request must not kill the whole run.**
*Layer:* `safety/block-detector.ts`, `crawler/request-gate.ts`.
*Change:* `detectBlock()` gained an `isMainDocument` flag; 403/429 only hard-stops on the main-frame
document navigation (a real access-denied or rate-limit *page*). The request gate passes
`isMainFrameDocument(response)`. CAPTCHA / portal-signature markers still block on any status.
*Cause:* a SPA fired a background data call that returned 403 while the page rendered fine; the old
code treated any 403 as a bot wall and stopped with zero states.
*Lesson:* distinguish the page from the page's chatter; default `isMainDocument = true` keeps
back-compat. → Phase 0.

**C-2 ✅ Anchors (`<a>`/`<area>`) are navigation, not form submits.**
*Layer:* `safety/classifier.ts`, `safety/types.ts`, `crawler/action-extractor.ts`,
`mcp-server/.../actions.ts`, `services/record-transition.ts`.
*Change:* a `tag` field threaded through the action descriptor. (a) An `a`/`area` tag counts as
positive read evidence even without an `href`. (b) An anchor inside a `<form>` no longer inherits the
form's `method`/`action`.
*Cause:* the legacy stack wraps the whole page in one big `<form method="post">`; every tile/link
inside looked like a non-idempotent POST, was classified `mutating`, and a read-only run couldn't get
past the dashboard.
*Lesson:* classify by the element's own semantics. Without this, the whole family of one-big-form
legacy portals is unmappable read-only. → Phase 0.

**C-3 ✅ Anchor tiles need a stable text locator in a re-rendering SPA.**
*Layer:* `crawler/clickables.ts`, `mcp-server/.../act.ts`.
*Change:* for an anchor tile with an unambiguous name, try the exact-text locator first, then fall
back to the DOM path; non-anchor clickables stay path-first.
*Cause:* SPA lists re-render and re-key between observe and act, so the DOM path was stale →
`click_failed`.
*Lesson:* in SPAs visible text is more stable than the DOM path for links; choose the locator by
element kind. → Phase 0.

**C-4 ✅ Role-less SPA clickables need a wider actionability budget.**
*Layer:* `mcp-server/.../act.ts`.
*Change:* role-less clickables (anchor tiles) get a 15 s trial budget; normal controls keep 5 s.
*Cause:* a tile in a re-rendering list took more than 5 s to become actionable → spurious
`click_failed`.
*Lesson:* scale the timeout to how dynamic the element is. → Phase 0.

**C-5 ✅ `selectOption` must fall back from value to visible label.**
*Layer:* `mcp-server/.../act.ts`.
*Change:* `selectOption(value)` falls back to `selectOption({ label: value })` when the bare value
matches nothing.
*Cause:* a trace author knows the visible label, not the server-assigned `value` of a legacy
`<select>`.
*Lesson:* accept the human-visible identifier and resolve it. → Phase 0 (prerequisite for Phase 2).

**C-6 ✅ Framework-bound inputs need real input/change/blur events.**
*Layer:* `mcp-server/runtime/login.ts` (`enterBound()`).
*Change:* after `.fill()`, dispatch `input` + `change` and blur, so a reactive, data-bound model
commits the value; no difference for plain HTML forms.
*Cause:* on the SSO/OAuth identity provider the login inputs are framework-bound; a bare `.fill()`
set the DOM value but not the model, submit was rejected, login outcome `unknown`.
*Lesson:* `page.fill()` isn't enough for data-bound SPA inputs — login and trace fills should always
dispatch the events a reactive model listens for. → Phase 0 (prerequisite for Phase 2).

**C-7 ✅ Non-http(s) hrefs must not reach URL parsing.**
*Layer:* `mcp-server/runtime/run-state.ts` (`isHttpUrl()` guard).
*Change:* `routeTemplateFor()` / `peekRouteTemplate()` return the href unchanged when it isn't an
absolute http(s) URL, instead of throwing in `new URL()`.
*Cause:* a legacy `javascript:` postback "Next" link crashed `act` with `ERR_INVALID_URL`.
*Lesson:* never assume an href is a URL; guard every URL parse. → Phase 0 (prerequisite for Phase 2).

**C-8 ⚠️ An unknown environment slug must not silently create a stray store.**
*Layer:* `store/src/db.ts` (`KNOWN_ENVIRONMENTS` guard), `store/src/import-agent.ts`
(`allowUnknown: true` when reading existing files).
*Change:* `dbPathFor()` rejects a slug outside a known set, explaining that a typo silently creates a
parallel `<name>.sqlite`; readers that enumerate existing files opt out.
*Cause:* a stray `PATHFINDER_ENV` produced a parallel store that crawl data leaked into — a direct
cause of SQ-1; a stray creds-source store was found beside the real ones.
*Lesson:* guarding the slug is right, but the fork re-hardcoded the known set (C-9). Upstream: one
source of truth plus a declarative production flag. → Phase 1.

**C-9 ⚠️ The environment enum was re-hardcoded instead of made freeform.**
*Layer:* `config/portal-schema.ts`, `config/load-portal.ts`, `vault/store.ts`, `store/db-types.ts`,
`mcp-server/tools/index.ts`, `mcp-server/services/start-run.ts`, `mcp-server/main.ts` +
`ba-main.ts` (default `production` → a dev slug).
*Change (fork):* `production | staging | sandbox` replaced by a different fixed triple of
client-specific tier names, duplicated across six-plus files; the MCP default env flipped from
`production` to a dev tier (the root of GC-22's silent fallback).
*Cause:* the client's tiers don't fit `staging`/`sandbox`, and a dev host not matching the
"non-production" hostname regex was gated as production.
*Lesson:* make the environment a freeform label with an explicit `production: true|false` flag;
collapse the enum into one source of truth; key the guard off the flag (or an explicit host
allowlist); add mutation tests. → D-1, Phase 1.

**C-10 ✅ A 13th documentation kind — `api_endpoint` — and element behaviour.**
*Layer:* `docs-model/schemas/doc-content.ts` + `doc-record.ts`, `docs/render/*`.
*Change:* an `api_endpoint` record kind (code `API`): `method`, `url_template` (path parameters
generalised, e.g. `/api/contracts/{id}`), `purpose`, optional `status_observed`, `request_shape`,
`response_shape`. `ScreenElement` gained an optional `behaviour` field (what the element does).
Export/render updated.
*Cause:* the BA could see captured `network_call` shapes but had no kind to document the backend
contract, and nowhere to say what a button does.
*Lesson:* let the BA promote an observed network shape into an evidence-linked API record; keep
`url_template` generalised and concrete URLs on the evidence (privacy by design). → Phase 0.

| # | Area | Severity of the problem fixed | Bring upstream? | Phase |
| --- | --- | --- | --- | --- |
| C-1 | Block-detection scope | High (zero-state runs) | Yes, as-is | 0 |
| C-2 | Anchor vs form-POST classification | **Blocker** for one-big-form legacy portals | Yes, as-is | 0 |
| C-3 | Anchor text locator in SPAs | High (`click_failed` churn) | Yes, as-is | 0 |
| C-4 | Actionability budget for SPA tiles | Medium | Yes, as-is | 0 |
| C-5 | `selectOption` label fallback | Medium | Yes, as-is | 0 |
| C-6 | Framework-bound login inputs | **Blocker** for SPA/SSO login | Yes, as-is | 0 |
| C-7 | Non-http href guard | High (`act` crash) | Yes, as-is | 0 |
| C-8 | Stray-store guard | High (scattered scans) | Idea yes; pair with C-9 done right | 1 |
| C-9 | Freeform environment + prod flag | High (gating + scatter) | Yes, but **properly** (not re-hardcoded) | 1 |
| C-10 | `api_endpoint` kind + element behaviour | Medium (BA depth) | Yes, as-is | 0 |

### 6.2 Hook patterns (H-1 … H-4)

Portal hooks are the owner's trusted code that runs at crawl lifecycle points (the crawler never
writes them). Portal-X needed four, reproduced as de-identified patterns — client selectors, cookie
names, hostnames and URL fragments are replaced with placeholders. Lifecycle points used:
`onPageLoad` (after a page settles, before it is observed) and `onBeforeClickAction` (before a
click).

#### H-1 — Pre-run cookie to unlock hidden content

**Problem class:** part of the content is hidden unless a feature-flag cookie is present on the
portal host; without it the page renders "nothing to show" and the crawl records a hollow screen.

**Pattern** (`onPageLoad`): on every page load, add the cookie if it's absent (authenticated pages
read it after login).

```ts
export const setFeatureCookie: Hook<'onPageLoad'> = async (ctx) => {
  const present = (await ctx.cookies.get()).some((c) => c.name === '<FLAG_COOKIE>');
  if (present) return;
  // the browser driver wants url XOR domain+path — pass only `url` and let it derive host + "/".
  await ctx.cookies.add([{ name: '<FLAG_COOKIE>', value: '<VALUE>', url: ctx.config.base_url }]);
  ctx.log('feature cookie set on the portal host (post-login page load)');
};
```

**Lessons:** content can be gated on client-side state the crawler must seed; the driver's
`cookies.add` rejects `url` together with `domain`+`path`, so pass only `url`; upstream this is a
declarative `cookies:` list in the portal file, with the hook as the escape hatch. → Phase 5.

#### H-2 — Expand collapsed content before observing

**Problem class:** important links/fields live inside collapsed accordions, native `<details>` and
"show more" toggles; the snapshot and screenshot miss them, so the BA never sees the page's services.

**Pattern** (`onPageLoad`, in-page): open everything collapsed — native `<details>:not([open])`,
`aria-expanded="false"` toggles, section-header links (`dl dt > a[href="#"]`), "show more" controls —
with four safety rails:

1. **Suppress programmatic form submits** while expanding (override `HTMLFormElement.prototype`
   `submit`/`requestSubmit` with no-ops, restore afterwards), so a toggle inside the page-wide form
   can't post the page away.
2. **Never click** real off-page links, submit buttons, comboboxes/popup openers or disabled controls.
3. **Only click a toggle whose panel is actually hidden.** Clicking an already-open header collapses
   it — observed to drop a page's service links from ~20 to ~2. Decide open/closed from the
   controlled region's visibility (`hidden`, `aria-hidden`, `display:none`, `visibility:hidden`,
   `offsetParent === null`).
4. **Cap** the number of expansions (e.g. 60).

```ts
export const expandCollapsed: Hook<'onPageLoad'> = async (ctx) => {
  const opened = await ctx.inPage(() => {
    const proto = HTMLFormElement.prototype;
    const origSubmit = proto.submit, origReq = proto.requestSubmit;
    proto.submit = function () {}; proto.requestSubmit = function () {};
    let count = 0; const MAX = 60;
    // 1) native <details>; 2) aria-expanded="false"; 3) dl>dt>a[href="#"]; 4) "show more"
    //    … click only when the controlled region is genuinely hidden …
    proto.submit = origSubmit; proto.requestSubmit = origReq;
    return count;
  });
  if (opened > 0) ctx.log(`expanded ${opened} collapsed section(s)`);
};
```

**Lessons:** this fixes "snapshots/screenshots with content still hidden". The non-obvious bug was
rail 3. Upstream it became a declarative `expand_toggles:` config (enabled, paths, selectors,
exclude, max) with the same submit-suppression and hidden-only rule. → Phase 5 (GC-19).

#### H-3 — Wait for a late-mounting micro-frontend before clicking

**Problem class:** a service form's body is rendered by a micro-frontend that mounts after the shell
settles; the click arrives before the form exists.

**Pattern** (`onBeforeClickAction`): on pages hosting the micro-frontend, tell the server to wait for
the mount point to be filled; harmless elsewhere.

```ts
export const waitForLateForm: Hook<'onBeforeClickAction'> = (ctx) => {
  if (/<SERVICE_PAGE_PATH_PATTERN>/i.test(ctx.url)) {
    return { waitFor: '[data-mfe-mount] :not(:empty), .mfe-root form, main form' };
  }
  return undefined;
};
```

**Lessons:** "page settled" (network idle / load) is not "content ready" when a micro-frontend
mounts late; a per-page, condition-based wait fixes it — the seed of the single condition + deadline
wait in D-2. → Phase 4 (content-ready) and Phase 5 (wait model).

#### H-4 — Classify SPA vs legacy server-rendered pages (read-only)

**Problem class:** the portal mixes a modern SPA shell with legacy server-rendered pages; each state
should be tagged "new SPA" or "legacy" (migration candidate).

**Pattern** (`onPageLoad`, read-only, in-page): the reliable positive signal is the SPA's mount
container; its absence means legacy. Corroborate with generic framework fingerprints and log a
verdict into the state's decision log.

```ts
export const detectStack: Hook<'onPageLoad'> = async (ctx) => {
  const r = await ctx.inPage(() => {
    const spa = document.querySelector('<SPA_MOUNT_SELECTOR>') !== null;
    const signals = [];
    // generic, non-client fingerprints only (placeholders — fill with the stack's own markers):
    if (document.querySelector('<LEGACY_SERVER_STATE_FIELD>'))
      signals.push('legacy:server-rendered page stack');
    // (plus generic CMS url/marker checks)
    return { spa, signals, title: (document.title || '').slice(0, 80) };
  });
  ctx.log(r.spa ? `stack:spa present` : `stack:legacy ${r.signals.join('; ')}`);
};
```

**Lessons:** a cheap read-only hook turns a crawl into a **migration inventory**. A legacy
server-rendered stack exposes a reliable hidden server-state field usable as a marker (describe the
behaviour, don't name the framework). Pairs with C-2. → Not on the roadmap; remains a hook example.

#### ⚠️ The `esbuild`/`tsx` `__name` in-page gotcha

Any function passed to `ctx.inPage(fn)` is serialised and evaluated in the page. Under `tsx`,
esbuild wraps **named** functions/arrows in `__name(...)`, which doesn't exist in the page →
`ReferenceError: __name is not defined`.

**Rule:** the in-page body must be flat — no named inner helpers, no const-bound arrows that esbuild
annotates; only anonymous expressions (anonymous `function () {}` prototype overrides are fine).
**Upstream:** a documented `NAME_SHIM` that defines `__name` in the page before an in-page eval, or a
build step that strips the annotation for hook bodies. → Phase 5 (hook-authoring docs).

#### Takeaways for the hooks system

- The four hooks map to a general need: **seed** state (cookie), **reveal** state (expand), **await**
  state (late mount), **observe** state (classify). A mature hooks API makes all four easy and safe
  (submit suppression, hidden-only clicks, read-only guarantees).
- Prefer declarative config for the common cases, with hooks for the bespoke 10% (D-3).
- Document the `__name` gotcha prominently; it will bite every in-page hook author.

### 6.3 Trace-driver pattern: forcing a form process to completion

This addresses the pain called out as most important: *forcing the scanner to actually finish a form
process.* The fork solved it with a reusable trace-driver layer on top of `mode:"trace"`.

**The problem.** In `map` mode the crawler explores breadth-first and stops at the first irreversible
action — right for discovery, but a multi-step form is never driven to its end. Asking the agent to
"just finish the form" is unreliable: it wanders, re-maps, or stops at a boundary.

**The solution has two pieces.**

**1. `portals/<portal>/traces.yaml` — one entry per named process.** A trace pins a process to a
start node (`start_url`) and lists the ordered field interactions, the `advance` controls (to move a
multi-page form forward) and the final `submit` control. Each trace runs one or more variants:

- **happy-path** (`expect: proceed`) — valid input; the form must advance past submit.
- **validation-error** (`expect: validation_error`) — a required field omitted; the form must refuse,
  and the driver scrapes and records the exact error message(s).
- **loading** — whatever pending state (spinner, disabled button, interstitial) appears between submit
  and result is captured (honestly "none observed" for a classic full-page postback).

```yaml
traces:
  - id: send-message
    name: Send a message
    goal: Document the general contract message form — happy path, validation errors, loading state.
    start_url: https://<portal-host>/<path-to-form>      # anonymise host+path upstream
    steps:
      - match: "<contract select label>"
        kind: select
        value: "<visible option label>"   # label, not internal value (see C-5)
        intent: Choose which contract the message is about
      - match: "<category>"
        kind: check
        intent: Choose the message category
      - role: textbox
        kind: fill
        value: "Synthetic test message for process documentation. No real data."
        intent: Enter the free-text message
    advance: ["Next"]          # generic: the "move forward" control
    submit: "Send|Submit"      # the irreversible action
    variants:
      - { id: happy-path, expect: proceed }
      - { id: missing-contract, expect: validation_error, steps: [ { role: textbox, kind: fill, value: "…", intent: "message only, contract left unset" } ] }
      - { id: empty-message,    expect: validation_error, steps: [ { match: "<contract>", kind: select, value: "<label>", intent: "contract only, message empty" } ] }
```

**Stubs:** a process can be listed with `to_be_discovered: true` and no steps, so the full catalogue
of intended processes lives from day one; the driver skips stubs until a map discovers the page and
the steps are filled in — a way to track "processes we know exist but haven't driven yet".

**2. The `run-trace` driver.** A dependency-free script reads `traces.yaml`, logs in as the persona
(vaulted credentials — never seen), navigates to `start_url`, fills each field with synthetic
values, clicks `advance` then `submit`, and lets the MCP server record a `processes` row with ordered
`process_steps`.

**Privilege decides submit vs boundary** (the safety model stays intact):
- A high-privilege persona (ceiling `external-side-effect`) → the submit is executed and the trace
  records the result page.
- A lower-ceiling run → the submit is refused and the trace stops at `boundary_reached`; what happens
  after submit is honestly "not observable". Lower `max_action_class` to get the safe stop.

**Synthetic-data discipline:** values must be synthetic (emails on `.invalid`/`.test`/`.example`);
the server rejects suspected PII on portals that scrub.

**Why this is the right shape.**
- **Deterministic** — the form is driven the same way every run; no agent wandering.
- **Variant-first** — happy path, validation and loading are separate, inspectable runs, each its own
  `processes` row: exactly what a BA needs for a use case (main flow + exception flows).
- **Declarative** — adding a process is a `traces.yaml` entry, no code.
- **Safe** — the persona ceiling, not the driver, decides whether the real submit fires.

**Core prerequisites** (Phase 0): C-7 (`isHttpUrl` — a `javascript:` postback "Next" no longer
crashes `act`), C-5 (`selectOption` label fallback), C-6 (framework-bound fill).

**Upstream recommendation** — bring it into MudPuppy as a first-class feature, not a side script:
1. A `traces.yaml` schema in `config` (validated like portal/persona files), with
   `to_be_discovered` stubs.
2. A `pnpm trace <portal> <trace-id|all> <persona> --env <env> [--variant …]` command driving
   `mode:"trace"` runs headless and bounded, one `processes` row per variant.
3. Validation messages recorded as business-rule candidates; each variant rendered as a flowchart in
   the dashboard Process tab with the start node marked.
4. A BA follow-up loop: the BA names processes → stubs appear in `traces.yaml` → a map discovers the
   page → steps filled → the driver runs the variants → the BA turns them into use-case records. This
   closes the "map → document → trace → document" loop the README already promises.

*Consolidation note.* Two later findings bear directly on the driver: SQ-8 (its per-variant runs must
be reconciled by `narrow` before the BA documents them — hence ➕ run tagging) and SQ-7(d) (a
process reachable only through UI navigation degrades to an error-page stub when deep-linked via
`start_url` — hence ➕ navigation reach). Both are in the Phase 2 table.

---
### 6.4 Field issues (GC-01 … GC-22)

The issue log from running MudPuppy against Portal-X, de-identified (original ids replaced with
neutral `GC-NN`; the mapping is intentionally not published). Severity: 🔴 blocker · 🟠 high ·
🟡 medium. Each: symptom → cause → fix/workaround applied → upstream direction → phase.

#### Group A — First start, environment & setup

**GC-01 🟡 Robots compliance is pointless on a private dev tier.** A dev/acceptance tier served
`Disallow: /` (or the compliance gate blocked the run) although it's private and authorised.
*Cause:* robots/compliance gating assumes a public production site. *Fix:* `robots: ignore` per
portal; declare the tier non-production. *Upstream:* tie strictness to the declared
`production: false` flag (D-1). → Phase 1.

**GC-02 🟠 No first-start "doctor" diagnosis.** The first run against a new corporate portal failed
for environmental reasons (proxy, CA, UA, allowlist) with errors that didn't point at the cause.
*Fix:* diagnosed by hand. *Upstream:* a doctor stage driven by an extensible registry (id,
applies_when, depends_on, probe, signature, fix, inputs); only inputs are site-specific; new checks
need no core change. → Phase 3.

**GC-03 🟠 Reachable only through a corporate forward proxy.** All requests failed / 403 until routed
through the proxy. *Cause:* the site's egress allowlist only admits the proxy's IP, and `HTTPS_PROXY`
wasn't honoured by the gate's `route.fetch`. *Fix:* opt-in `network.proxy { server, bypass, enabled }`
in the portal file. *Upstream:* first-class, agnostic `network.proxy` in the request gate. → Phase 3.

**GC-04 🟡 Windows PAC proxy discovery from WSL.** The proxy couldn't be discovered automatically from
WSL (Windows PAC file). *Fix:* resolved by hand. *Upstream:* an optional PAC/doctor probe that
suggests the proxy (input-only, agnostic). → Phase 3.

**GC-05 🟠 IP-allowlist 403 ("not whitelisted").** `RUN_STOPPED` HTTP 403, 0 states, before any page.
*Cause:* as GC-03 — not using the allowlisted egress. *Fix:* route via `network.proxy`. *Upstream:*
the doctor's `net.ip-allowlist` check recognises this 403 and points at the proxy. → Phase 3.

**GC-06 🟡 Native build toolchain (better-sqlite3) missing.** Install failed building a native module
on a locked-down box. *Fix:* `--ignore-scripts`. *Upstream:* document the prebuilt /
`--ignore-scripts` path; doctor `toolchain.native-build` check. → Phase 3.

**GC-07 🟡 WAF blocks a non-browser User-Agent.** The IdP/WAF returned 403 for a crawler-looking UA
before the login form rendered (proven: crawler UA → 403; a real browser UA → normal 302 → 200).
*Fix:* a realistic browser UA in `rate_limit.user_agent` per portal. *Upstream:* doctor
`waf.user-agent` check; document UA gating. Keep the UA in config, never in code, and never commit a
client's exact UA. → Phase 3.

**GC-22 🟠 Silent default-env fallback → MCP operates on the wrong environment.** *(Recorded
2026-10-15, record-only; the operational face of C-9 / D-1.)* While working on env **B**, MCP calls
kept going to env **A**: the dashboard and chat served B, the MCP servers talked to A.
*Cause:* `mcp.json` pins `PATHFINDER_ENV` to a default tier and was restored to it after a session
that had flipped it to B, so every new agent session started the MCP servers on A — a silent
fallback contradicting the dashboard/chat. The project's own rule (`PATHFINDER_ENV` in `mcp.json`
must match the `--env` passed) was broken by the default, not by the operator. Compounded by
long-lived (~1.5 h) MCP server processes from a different checkout with a third `PATHFINDER_ENV`, so
which store a call hit depended on which process answered. *No data corruption observed* —
store-modification times show the session's narrow + document work landed on B; A held only a few
stray login-only records from an earlier mis-env'd run — but the risk was real.
*Status:* open (operator decision pending on config and stray processes).
*Upstream:* (1) no silent env fallback — refuse to start or demand an explicit env; (2) an
env-agreement check across the MCP server, dashboard and chat orchestrator; (3) a per-data-dir
PID/lock to detect stray servers; (4) the current env visible in every MCP result and the dashboard
header. *Cross-refs:* C-8, C-9, D-1, GC-01. → ➕ Phase 1.

#### Group B — Auth, SSO & long redirect chains (the big design topic)

**GC-08 🔴 Login wait vs rate limit (SPA login form renders late).** `control_not_found`: the login
form appeared only after dozens of chunked requests; at the polite rate (~2 req/s) that exceeded the
fixed login timeout. *Cause:* fixed timeouts that ignore our own rate limiter. *Fix:* opt-in
`login.wait { form_ms, success_ms, poll_ms, enabled }` + a faster rate on the dev tier. *Upstream:*
part of D-2 — waits derived from the limiter; separate rate limits for static assets vs the main
document. → Phase 5.

**GC-09 🔴 Auth flows & multi-hop cross-host redirect chains (the main design topic).**
`failed / unknown` and effective lockout although the user does land on the dashboard; the success
check ran while still on the IdP host mid-redirect. *Cause:* four compounding things — fixed timeouts
ignoring the limiter, a single-shot success check, multi-hop cross-host redirects, and
ambiguous = failed = locked out. *Fix:* per-portal `login.success`/`failure` markers (success = a URL
not matching the IdP host; failure = an error-banner text absent on a fresh form), longer waits.
*Upstream (design, D-2):* condition waits with a deadline that extends on progress; a `pending`
outcome; budgets derived from the limiter; per-portal transit zones; a recorded navigation chain;
one wait mechanism shared by login, navigate and act. → Phase 5.

**GC-10 🟡 Redactor masks the persona id.** `runs.persona_id` came back `[secret]` because the
persona id equalled the login name. *Fix:* renamed the persona. *Upstream:* redact credential values,
not an id that merely matches one. → ➕ Phase 5.

**GC-11 🟡 Identity-provider error page → blank evidence, wrong reason.** A transient IdP error page
(message rendered by script seconds later) produced a state with an empty snapshot and blank
screenshot, and login reported `control_not_found`; the next run was fine. *Cause:* evidence captured
before the late error text; transient error misattributed. *Upstream:* wait for the error text before
capturing; classify a transient IdP error distinctly; retry. → Phase 5.

#### Group C — Network, TLS & rendering

**GC-12 🟠 TLS inspection + per-host proxy routing.** Third-party asset hosts failed when forced
through the single proxy (TLS-inspected cert, 403), while the portal host needs the proxy. *Cause:*
one proxy for everything is wrong; direct traffic is TLS-inspected and needs the corporate CA.
*Fix:* `network.proxy.bypass` for asset/CDN hosts + `network.ca_certificates` (never commit CA paths
or contents). *Upstream:* per-host routing (proxy vs direct) + a CA-trust option; doctor
`net.tls-inspection`. → Phase 3.

**GC-13 🟠 Unstyled pages/screenshots because a stylesheet was blocked.** *Cause:* the proxy refused
the third-party CDN; the page half-rendered. *Fix:* `network.asset_check { enabled, resource_types,
recapture }` + a bypass for asset hosts; emit `asset_check:failed` and `render_warnings` on the state.
*Upstream:* an asset-health check that warns when key assets fail and optionally recaptures once they
load (SQ-4). → Phase 3.

#### Group D — Classification & safety

**GC-14 🟠 German submit labels classified as "read".** A read-only persona clicked a German
send/submit link and the server logged a form POST — the submit keyword rules were English/Polish
only. *Fix:* per-portal `action_rules` `submit_request` keywords in German (Senden, Absenden,
Abschicken, Speichern, Bestätigen, Weiter, Hochladen, Beantragen). *Upstream:* a multi-locale,
locale-aware submit-keyword dictionary (DE at least). → Phase 0.

**GC-15 🟠 A `javascript:window.open(...)` link breaks the browser session.** Clicking a popup/chat
link returned `INTERNAL`, the item was handed out again, and `finish_run` refused with
`FRONTIER_NOT_EMPTY` (stuck run). *Cause:* a `javascript:` popup href is neither navigable nor safe,
and `path:` rules aren't checked for `javascript:` hrefs. *Fix:* `action_rules: [{ id: js-popup,
class: external-side-effect, paths: ["**window.open(**"] }]` + `denylist: [js-popup]`. *Upstream:*
treat `javascript:` hrefs as non-navigable by default; let an unactionable frontier item be retired,
not re-handed (GC-18). → Phase 4.

#### Group E — Cost & frontier efficiency

**GC-16 🟠 Mapping cost dominated by refusal churn.** ~60 credits for one small logged-in map; in
one run 148 of 165 turns were a `click_failed` refusal + `get_next_frontier_item`; 45% of a day's
tool calls were in runs that never completed. *Cause:* hidden/unclickable items issued; refusals
without `next`; no server-side batching; shared nav not de-duplicated. *Upstream (high value):* don't
issue hidden/unclickable items; `next` in refusals; server-side batch drain for read-only maps; dedup
shared nav; cost per run in the dashboard (`agent_turns`). → Phase 4.

**GC-17 🟡 Credential bulk import.** No convenient way to import many personas' credentials.
*Status:* open. *Upstream:* a bulk `vault` import (file of refs → encrypted store), no plaintext on
argv. → Phase 5.

**GC-18 🔴 Resumed run wedged in `running` (`FRONTIER_NOT_EMPTY`).** Several runs stuck; `finish_run`
refused because the frontier never emptied (fed by GC-15-type items and GC-16 hidden items).
*Upstream:* record and retire an unactionable item instead of re-queuing it forever; let `finish_run`
complete with a documented remainder. → Phase 4.

**GC-19 🟠 Collapsed content not expanded (see H-2).** Recorded states missed links/fields inside
closed accordions. *Fix:* the `expand_toggles` hook/config. *Upstream:* ship `expand_toggles` as
declarative config with the hidden-only + submit-suppression rules. → Phase 5.

#### Group F — BA evidence selection & citation

*(Recorded 2026-10-15; not yet reproduced or fixed. Downstream of SQ-8.)*

**GC-20 🟠 BA skips interrupted-but-rich trace runs ("completed-only" rule).** A traced form process
was documented thinly (one step, or only the last-step screenshot) though a far richer trace existed.
*Cause:* the BA practice says to use every *completed* run ("all completed map runs, plus trace
runs"); an interrupted trace run — which can hold the most steps and screenshots, cut off *after* the
richest work — is skipped by rule, so a `goal_reached` 6-step run beats an interrupted 12-step run
with 8 screenshots. *Status:* open. *Upstream:* select runs by evidence richness and outcome honesty:
(a) let the BA document interrupted trace runs with an honest `observed_extent`
(`until_boundary`/partial); (b) per-run step/screenshot counts in `list_runs`; (c) a data-hygiene
pass that marks a good interrupted run usable or de-dups thin variant runs. → ➕ Phase 5.

**GC-21 🟠 BA under-cites screen regions (one per record, not one per step/state).** A multi-step
process showed one screenshot + wireframe for the whole record; most steps and both validation-error
states showed no evidence. *Cause:* the practice already says to cite the touched control's region
per step and per variant state, but the model under-applied it and nothing enforced it. *Status:*
open (guidance exists; adherence and enforcement don't). *Upstream:* a documentation quality check
that flags `use_case`/`process` records whose steps or variant states lack a cited `screen_region`,
plus tighter guidance — the citation half of the SQ-6 gate. → ➕ Phase 5.

#### Cross-cutting themes

1. **The corporate environment is the hard part** (A + C) — a doctor + agnostic `network.*` config
   removes most first-day pain.
2. **Auth is a design problem, not a timeout tweak** (B) — condition-based waits, a `pending`
   outcome, transit zones, one wait mechanism (D-2).
3. **The frontier wastes money** (E) — fix issuance, retirement, batching and dedup.
4. **Content is often hidden or late** (H-1…H-3, GC-13, GC-19) — seed, reveal and await before
   observing; recapture when assets fail.
5. ➕ **Evidence selection matters as much as evidence capture** (F, GC-22) — the right runs, on the
   right environment, reconciled before documenting.

### 6.5 Scan-quality findings (SQ-1 … SQ-8)

The quality problems observed in the fork's runs, each tied to evidence and a root cause. These are
assessment findings; the fixes live in the roadmap.

**SQ-1 🟠 Scattered scans / data split across stores.**
*Observed:* more than one `*.sqlite` store under the data dir — the two intended tier stores plus a
leftover `sandbox` store and a stray, typo-named one (now deleted); crawl data split across them, so
"where did my run go?" was ambiguous and maps looked smaller than they were.
*Root cause:* `dbPathFor()` accepted any slug and silently created `<name>.sqlite`.
*Direction:* the C-8 guard stops the stray store; the real fix is the freeform env + `production`
flag with one source of truth (C-9, D-1). Add a dashboard view listing every store with its run
count. → Phase 1.

**SQ-2 🟠 Duplicate / repeated screens.**
*Observed:* the same screen recorded more than once; the crawl re-visited states instead of pushing
into new ones; docs showed "one screen twice".
*Root causes (compounding):* (1) state identity in a re-rendering SPA — slightly different snapshots
make one screen look like several, and stale locators (C-3) made the crawler fail to move and retry
the same place; (2) frontier issuance — hidden items handed out, refused and re-handed (GC-16).
*Direction:* C-3 reduces re-render churn; GC-16/18 fixes stop the re-touch loop; run and watch the
existing `stability` tool between runs; warn when two states share a route template and
near-identical layout. → Phases 0 and 4.

**SQ-3 🟠 Frontier not advancing; re-scanning instead of pushing.**
*Observed:* runs spent most turns on `click_failed` + `get_next_frontier_item` without new states;
several never completed (wedged in `running`).
*Evidence:* 148 of 165 turns in one logged-in map were refusal + poll; 45% of a day's tool calls were
in runs that never completed; several runs stuck with `FRONTIER_NOT_EMPTY`.
*Root cause:* unactionable items issued (hidden, unclickable, `javascript:` popups — GC-15); refusals
didn't advance; unactionable items re-queued forever (GC-18).
*Direction (highest leverage):* don't issue hidden items; retire unactionable items; `next` in every
refusal; server-side batch drain; dedup shared nav. → Phase 4.

**SQ-4 🟠 Screenshots of not-fully-loaded pages.**
*Observed:* unstyled pages, or a shell without its late-mounted form/content.
*Root causes:* (1) blocked assets — a stylesheet from a blocked CDN never loaded (GC-13); (2) late
content — network idle fired before a micro-frontend mounted (H-3), and a transient IdP error
rendered after capture (GC-11).
*Direction:* an asset-health check with recapture; a content-ready condition (not just network idle)
before capture — the same condition-based wait as H-3/D-2. → Phases 3 and 4.

**SQ-5 🟠 "Scan from a point in the graph" starts a fresh crawl.**
*Observed:* scanning part of a process from a chosen node seemed to start over.
*What exists:* `start_run` supports `focus { start_url, only_domains, only_paths, exclude_paths }`,
and the trace driver uses `focus.start_url`.
*Gaps:* (1) a focused map re-discovers the subtree from scratch instead of attaching to the existing
graph; (2) `focus.only_paths` applies to every request including the login redirect, so a
login-gated start node needs `only_paths` omitted, or the login hops are fenced out — easy to get
wrong and it looks like a failed or fresh run.
*Direction:* a true resume-from-node mode (seed the frontier from an existing state's unexplored
actions, reuse states by fingerprint, don't re-walk known nav); document the focus + login-redirect
interaction. → Phase 4, D-5.

**SQ-6 🟠 BA documentation is thin / low quality.**
*Observed:* lots of raw data but weak docs — a screen recorded twice, no business requirements;
"garbage in, garbage out".
*Root causes (layered):* (1) input quality — SQ-2 duplicates are documented faithfully; (2) shallow
traversal — forms never driven to completion, so no process/use-case evidence; (3) guidance — screens
and data items but few requirements/rules/use cases, which need trace evidence and the analysis
passes actually run (capabilities → requirements → rules), with validation messages captured as rule
candidates.
*Direction:* fix inputs first (SQ-2, SQ-3); feed process evidence via the trace-driver loop; pair the
newer BA guidance with the `api_endpoint` kind (C-10); add a documentation quality gate that flags
screens with zero requirements/rules or duplicate screens sharing a route template. → Phases 2 and 5,
D-4.

**SQ-7 🟠 Rich evidence exists but the BA documents from the wrong runs.** *(Field diagnosis
2026-10-15; downstream of SQ-8.)*
*Observed:* a traced form process came out thin (one step, last-step screenshot only, or none) while
the store held a much richer trace; deep-linked variants of other processes landed on a generic
error-code page and were documented as 1–2-step `map_only` stubs.
*Root causes:* (1) run selection by status, not richness (GC-20); (2) under-citation (GC-21);
(3) messy inputs — near-duplicate variant runs and deep-link stubs crowded out the good evidence, and
a UI-navigation-only process was deep-linked, hit an error page and became a stub.
*Why re-running the BA won't fix it:* the richest run stays interrupted and the duplicates keep
producing thin pages; the fix is a coordinated data-hygiene + run-selection change.
*Direction:* select by richness with honest partial `observed_extent`; one `screen_region` per
step/state; de-dup / mark usable; reach UI-only processes by navigation, not deep-link. → ➕ Phase 5
(and ➕ Phase 2 navigation reach).

**SQ-8 🔴 The reconciliation ("narrow") step was skipped, so the BA documented un-grouped runs.**
*(Grounded field diagnosis 2026-10-15; the deeper root cause behind SQ-7 / GC-20 / GC-21 — a skipped
pipeline stage, not a BA defect.)*
*Observed:* one journey had ~16 raw trace runs that were never merged; the BA produced one thin
process doc per leftover run — duplicates, one-step stubs, inconsistent screenshots.
*Root cause:* `narrow` never ran — the grouping/variant tables were empty (zero suggestions, zero
grouped processes, zero variants); the BA then documented raw, ungrouped runs. Re-running the BA
can't fix this; it operates downstream of the missing grouping. (How the pipeline is meant to work:
§6.6.)
*Fix order:* (1) run `narrow` — one `ba_process` per journey with happy-path and each validation
error as variant branches; (2) run the BA over the reconciled processes, every step citing its
screenshot + wireframe.
*Caveats:* grouping suggestions come from the chat orchestrator service (the dashboard proxies to it
on its own port), which must be running; grouping writes to the store (revision-reversible).
*Product gaps:* `document` should refuse or warn when `narrow` produced zero grouped processes while
raw runs exist (D-8); the dashboard should show a skipped `narrow`. *Consequence:* because `document`
ran on raw runs, the written `PROC-*`/`UC-*` docs aren't keyed onto the reconciled `PRC-*` model —
the two-"processes" confusion in D-9. → Operational now; ➕ Phase 5 guard pulled into sprint 1.

**Source priority order for scan quality (`05`):** 1 SQ-8 · 2 SQ-3 · 3 SQ-4 · 4 SQ-2 · 5 trace
completion (`03`) · 6 SQ-6 · 7 SQ-7 · 8 SQ-5 · 9 SQ-1. (Merged with the roadmap in §2.)

### 6.6 The documentation pipeline and the two "processes"

**The five steps** (confirmed in the fork's schema and how-to-use; the `pipeline` step is a
CHECK-constrained enum with exactly these values):

```mermaid
flowchart LR
  scan --> map --> narrow --> document --> amend
  narrow:::owner
  classDef owner stroke-width:3px
```

| Step | Owner | Output |
| --- | --- | --- |
| scan / map | crawler + MCP server | runs, states (deduped by fingerprint), observations, `processes` / `process_steps` from traces |
| **narrow** | **chat orchestrator** (`apps/chat` `process-suggestions` / `process-service`) | `grouping_suggestions` → accepted into `ba_processes` with `process_variants` (branches, `branched_from`) — keys `PRC-*` |
| document | BA | `doc_records` — `process` (`PROC-*`), `use_case` (`UC-*`), screens, requirements, rules, `api_endpoint` … |
| amend | BA / human | revisions and review state |

**Key rules of the model.**
- **States are deduped by fingerprint, never overwritten.** Observations hold many sightings of a few
  distinct states across runs; the same screen in many runs is one state linked to all of them.
- **A validation error is its own extra step**, whose `state_after` is the error state (e.g. "heading
  count changed 4 → 5"). Error paths are extra steps/states by design.
- **Reconciliation is `narrow`'s job, not the BA's.** Accepting a grouping creates a single process
  with variants as branches — happy-path / missing-contract / empty-message — so an error path is
  one extra branch, not N duplicate processes. The BA documents a process; it does not merge runs.

**The two layers both called "processes"** (D-9):

| | Processes tab (top nav) | Docs → "Processes and use cases" |
| --- | --- | --- |
| Reads | `ba_processes` + `process_variants` | `doc_records` of kind `process` and `use_case` |
| Keys | `PRC-nnn` | `PROC-nnn`, `UC-nnn` |
| Produced by | `narrow` | `document` (BA) |
| Shows | journeys with variants (A = as-is, B/C = to-be), grouping suggestions, loose un-grouped screens, a stage; compare / draw / version | written records with evidence, screenshots, revisions, review state; step narrative + flows |
| Mental model | *the model* — the canonical list of business processes and their variants | *the deliverable* — the written documentation of those journeys |

On the engagement the BA wrote `PROC-*` from raw trace runs **before** reconciliation, while `PRC-*`
came from a later `narrow`: same journeys, never re-keyed 1:1, and nothing cross-links them.

### 6.7 Proving-ground candidates (groups A–G)

Disposable scenarios for `apps/proving-ground`, so each lesson is reproducible locally without the
real (allowlisted, client) site. The fork proved that a dependency-free local quirks server with
per-quirk switches can simulate all of them. No client data: quirks are staged on fake hosts such as
`portal.local`, `idp.local`, `cdn.local`. Switch names are suggestions.

#### A. Classification & navigation (highest value: unblocks legacy + SPA)

| Switch | Reproduces | Before → after |
| --- | --- | --- |
| `ONE_BIG_FORM=1` | A page wrapped in one `<form method="post">` with `<a>` navigation tiles inside | Tiles classify `mutating`, crawl stuck at the dashboard → (C-2) tiles classify `read`, crawl proceeds |
| `SPA_RERENDER=1` | A list that re-renders/re-keys tiles between observe and act | Stale DOM path → `click_failed` → (C-3) relocated by exact text |
| `SLOW_TILE_MS=8000` | A role-less tile actionable after ~8 s | 5 s trial → refused → (C-4) 15 s budget clicks it |
| `SELECT_BY_LABEL=1` | A native `<select>` whose option values differ from labels | `selectOption(value)` matches nothing → (C-5) falls back to `{label}` |
| `JS_POSTBACK=1` | A "Next" link with a `javascript:` postback href | `act` crashes `ERR_INVALID_URL` → (C-7) guarded, non-navigable |
| `DE_SUBMIT=1` | A German "Senden"/"Weiter" submit link | Classified `read`, read persona posts the form → (GC-14) DE lexicon classifies it as submit |

#### B. Content readiness (stops junk evidence)

| Switch | Reproduces | Before → after |
| --- | --- | --- |
| `LATE_MFE_MS=1500` | A form body mounted by a micro-frontend ~1.5 s after the shell settles | Click into nothing / empty-shell screenshot → (H-3) wait for the mount point |
| `COLLAPSED=1` | Links/fields inside closed `<details>` and `aria-expanded="false"` accordions | Snapshot/screenshot miss them → (H-2) expanded (hidden-only, submit suppressed) |
| `COLLAPSED_DEFAULT_OPEN=1` | Some sections open by default | Guard case: naive "click all toggles" collapses them (links ~20 → 2) → (H-2) only hidden panels clicked |
| `CDN_CSS=1` + `BLOCK=cdn.local` | Stylesheet from a blocked CDN | Unstyled page + screenshot → (GC-13) `asset_check:failed` warning + recapture |
| `FLAG_COOKIE=1` | A list hidden unless a feature cookie is set | Empty "nothing to show" → (H-1) cookie seeded, list renders |

#### C. Frontier efficiency & wedged runs (biggest cost win)

| Switch | Reproduces | Before → after |
| --- | --- | --- |
| `HIDDEN_ITEMS=1` | Hidden / `display:none` clickables | Issued, refused, re-issued → (GC-16) never issued |
| `JS_POPUP=1` | A `javascript:window.open(...)` link | `INTERNAL`, re-handed, `FRONTIER_NOT_EMPTY` → (GC-15/18) recorded + retired, run completes |
| `SHARED_NAV=1` | A global nav repeated on every page | Re-walked on each state → (GC-16) deduped |
| `MANY_READ_LINKS=40` | A page with many read-only links | One turn per link → (GC-16) server-side batch drain |

Metrics to assert: **turns per new state** below a target; **refusal rate** below a target; the run
reaches `completed` (no `FRONTIER_NOT_EMPTY`).

#### D. Auth, SSO & redirect chains (the design-heavy set)

| Switch | Reproduces | Before → after |
| --- | --- | --- |
| `SPA_LOGIN_CHUNKS=60` | Login form renders only after ~60 chunked requests | `control_not_found` at polite rate → (GC-08/D-2) wait derived from the limiter / `login.wait` |
| `BOUND_INPUTS=1` | Framework-bound login inputs | Bare `.fill()` → submit rejected, `unknown` → (C-6) events dispatched, model commits |
| `AUTH_HOPS=2`, `HOP_DELAY_MS=1000` | Slow multi-hop cross-host 302 chain after an SPA callback | Success checked mid-chain → `failed/unknown` lockout → (D-2) condition wait + `pending` + transit zone |
| `HASH_ROUTE=1` | `#/login` → `#/redirecting` with no load event | Nothing to wait on → (D-2) condition-based wait |
| `IDP_ERROR_FIRST_N=1` | Transient IdP error page, message rendered by script after ~3 s | Blank evidence, `control_not_found` → (GC-11) wait for error text, classify transient, retry |
| `WAF_UA=1` | IdP/WAF 403 for a non-browser UA | 403, no form → (GC-07) realistic UA from config; doctor `waf.user-agent` |

#### E. Corporate network & environment (first-start pain)

| Switch | Reproduces | Before → after |
| --- | --- | --- |
| `ALLOWLIST=1`, `PROXY_SOURCE=127.0.0.2` | Site reachable only from the proxy's egress IP | `RUN_STOPPED` 403, 0 states → (GC-03/05) `network.proxy` via the allowlisted egress |
| `PROXY_ONLY_HOSTS=1` | Hosts resolvable only via the proxy; `HTTPS_PROXY` not honoured | DNS error / 403 → (GC-03) `network.proxy` in the portal file |
| `BLOCK=cdn.local` | Proxy refuses a third-party host | Half-rendered page → (GC-12) per-host routing + CA trust |
| `PROD_LOOKING_HOST=1` | A production-looking hostname for a dev site | `ENV_GUARD_REFUSED` with a non-prod env → (D-1) freeform env + `production:false` |
| `ROBOTS=deny` | `Disallow: /` on a dev tier | Refused navigations → (GC-01) `robots: ignore` tied to the non-prod flag |
| `STRAY_ENV_SLUG=1` | A typo'd `PATHFINDER_ENV` | Silent stray `<name>.sqlite` → (C-8) rejected with a helpful message |
| `UNSET_ENV=1` | `PATHFINDER_ENV` unset/ambiguous at MCP start | Silent default to a tier, mismatching dashboard/chat → (GC-22) server refuses to start or demands an env |
| `ENV_MISMATCH=1` | MCP server on env A, dashboard/chat on env B | Confusing cross-env calls, wrong-store risk → (GC-22) start-up agreement check warns; env in every result/header |
| `STRAY_MCP_PROCESS=1` | A second MCP server from another checkout on the same data dir | Calls answered by an unrelated server → (GC-22) per-data-dir PID/lock warns |

#### F. Privacy / redaction

| Switch | Reproduces | Before → after |
| --- | --- | --- |
| `PERSONA_ID_EQUALS_LOGIN=1` | Persona id equals the login name | `runs.persona_id = [secret]` → (GC-10) redact credential values, keep the id readable |

#### G. BA run selection & documentation quality

Documentation-pipeline scenarios, not browser quirks: stage them with a small fixture store (a
disposable set of recorded runs for one fake process). Assertions run against the **exported
documentation** — e.g. every `use_case` step cites a `screen_region`; the richest trace per process
is the one documented; no two `screen` records share a route template with near-identical layout.

| Fixture | Reproduces | Before → after |
| --- | --- | --- |
| `RICH_INTERRUPTED_RUN=1` | A `goal_reached` 6-step run and an `interrupted` 12-step run with more screenshots | BA documents the thin run (GC-20) → selects by richness, documents the interrupted run with honest partial `observed_extent` |
| `DUP_VARIANT_RUNS=1` | Several near-duplicate variant runs for one process | Duplicates crowd out the good run (SQ-2/SQ-7) → de-dup / mark-usable, rich run wins |
| `MULTISTEP_PROCESS=1` | N steps + 2 validation-error states | One `screen_region` for the whole record (GC-21) → missing regions flagged; one per step/state |
| `DEEPLINK_BLOCKED=1` | A UI-navigation-only process; deep-link lands on an error-code page | Error page → 1–2-step `map_only` stub (SQ-5/SQ-7) → reached by navigation from a known node |
| ➕ `UNNARROWED_RUNS=1` | Raw trace runs for one journey, empty grouping/variant tables | BA documents raw runs (SQ-8) → `document` refuses/warns; after `narrow`, one process with variant branches |
| ➕ `ORPHAN_DOC_RECORDS=1` | `PROC-*`/`UC-*` records with no matching `PRC-*` | Two unlinked "processes" layers (D-9) → every doc record cross-links to a `ba_process` |

#### How to use the proving ground

1. Extend the proving-ground backend with these switches (the fork's `quirks-server.mjs` is a
   dependency-free reference implementation — re-implement, don't copy client config).
2. Add a gate case per candidate in the quality-gate suite, asserting the "after" symptom.
3. Wire each roadmap item to its gate case so a regression (or an un-landed fix) fails the gate.
4. Keep every scenario disposable and client-free — fake hosts, synthetic data, generic DOM.

The win: every lesson from Portal-X becomes a repeatable local test, so fixes land upstream with
confidence and the next engagement starts from a hardened base.

---
## 7. Traceability matrix

Every lesson id → where it lands on the roadmap → the proving-ground case that proves it. "Gap" marks
an id with no gate case in the source `08`; ➕ marks a placement or case added here.

| Id | Short name | Roadmap | Proving-ground gate |
| --- | --- | --- | --- |
| C-1 | 403/429 scoped to main document | Phase 0 | **Gap** — suggest `XHR_403=1` (a background call returns 403; the page renders) |
| C-2 | Anchor ≠ form submit | Phase 0 | A `ONE_BIG_FORM` |
| C-3 | Text-first anchor locator | Phase 0 | A `SPA_RERENDER` |
| C-4 | Wider actionability budget | Phase 0 | A `SLOW_TILE_MS` |
| C-5 | `selectOption` label fallback | Phase 0 (Phase 2 prereq) | A `SELECT_BY_LABEL` |
| C-6 | Framework-bound fill | Phase 0 (Phase 2 prereq) | D `BOUND_INPUTS` |
| C-7 | Non-http href guard | Phase 0 (Phase 2 prereq) | A `JS_POSTBACK` |
| C-8 | Stray-store guard | Phase 1 | E `STRAY_ENV_SLUG` |
| C-9 | Freeform env + prod flag | Phase 1 | E `PROD_LOOKING_HOST` |
| C-10 | `api_endpoint` kind | Phase 0 | Schema + render tests (not a browser case) |
| H-1 | Pre-run cookie | Phase 5 | B `FLAG_COOKIE` |
| H-2 | Expand collapsed content | Phase 5 | B `COLLAPSED`, `COLLAPSED_DEFAULT_OPEN` |
| H-3 | Late micro-frontend wait | Phase 4 (content-ready) / Phase 5 (wait model) | B `LATE_MFE_MS` |
| H-4 | SPA vs legacy classifier | Not on the roadmap (hook example) | — |
| GC-01 | Robots on a dev tier | Phase 1 (➕ own row) | E `ROBOTS` |
| GC-02 | No doctor | Phase 3 | Indirect — group E cases print a diagnosis |
| GC-03 | Proxy-only reachability | Phase 3 | E `PROXY_ONLY_HOSTS`, `ALLOWLIST` |
| GC-04 | PAC discovery from WSL | Phase 3 | **Gap** (environment-specific; doctor unit test) |
| GC-05 | IP-allowlist 403 | Phase 3 (➕ doctor check) | E `ALLOWLIST` |
| GC-06 | Native toolchain missing | Phase 3 | **Gap** (install-time; doctor unit test) |
| GC-07 | WAF blocks non-browser UA | Phase 3 | D `WAF_UA` |
| GC-08 | Login wait vs rate limit | Phase 5 | D `SPA_LOGIN_CHUNKS` |
| GC-09 | Multi-hop redirect chains | Phase 5 | D `AUTH_HOPS`, `HASH_ROUTE` |
| GC-10 | Redactor masks persona id | ➕ Phase 5 | F `PERSONA_ID_EQUALS_LOGIN` |
| GC-11 | Transient IdP error | Phase 5 | D `IDP_ERROR_FIRST_N` |
| GC-12 | TLS inspection + per-host routing | Phase 3 | E `BLOCK=cdn.local` |
| GC-13 | Blocked stylesheet | Phase 3 | B `CDN_CSS` |
| GC-14 | German submit labels | Phase 0 | A `DE_SUBMIT` |
| GC-15 | `javascript:` popup | Phase 4 | C `JS_POPUP` |
| GC-16 | Refusal churn / cost | Phase 4 | C `HIDDEN_ITEMS`, `SHARED_NAV`, `MANY_READ_LINKS` |
| GC-17 | Credential bulk import | Phase 5 | **Gap** (vault unit test) |
| GC-18 | Wedged run | Phase 4 | C `JS_POPUP` |
| GC-19 | Collapsed content | Phase 5 | B `COLLAPSED` |
| GC-20 | Completed-only run selection | ➕ Phase 5 | G `RICH_INTERRUPTED_RUN` |
| GC-21 | Under-cited screen regions | ➕ Phase 5 | G `MULTISTEP_PROCESS` |
| GC-22 | Silent default-env fallback | ➕ Phase 1 (guards in sprint 1) | E `UNSET_ENV`, `ENV_MISMATCH`, `STRAY_MCP_PROCESS` |
| SQ-1 | Store scatter | Phase 1 | E `STRAY_ENV_SLUG` |
| SQ-2 | Duplicate screens | Phase 0 (C-3) + Phase 4 | A `SPA_RERENDER`, C `SHARED_NAV`, G `DUP_VARIANT_RUNS` |
| SQ-3 | Frontier not advancing | Phase 4 | Group C + its metrics |
| SQ-4 | Unloaded screenshots | Phase 3 + Phase 4 | B `LATE_MFE_MS`, `CDN_CSS`; D `IDP_ERROR_FIRST_N` |
| SQ-5 | Scan-from-a-point starts fresh | Phase 4 (+ ➕ Phase 2 navigation reach) | G `DEEPLINK_BLOCKED` |
| SQ-6 | Thin BA docs | Phase 2 (loop) + Phase 5 (gate) | Group G assertions |
| SQ-7 | Wrong runs documented | ➕ Phase 5 | G `RICH_INTERRUPTED_RUN`, `DUP_VARIANT_RUNS`, `MULTISTEP_PROCESS`, `DEEPLINK_BLOCKED` |
| SQ-8 | `narrow` skipped | Operational + ➕ Phase 5 (sprint 1) | ➕ G `UNNARROWED_RUNS` |
| D-1 | Environment model | Phase 1 | E `PROD_LOOKING_HOST` |
| D-2 | Wait & auth model | Phase 5 (primitive in Phase 4) | Group D |
| D-3 | Hooks vs config | Phase 5 | B `FLAG_COOKIE`, `COLLAPSED` (config form) |
| D-4 | BA quality bar | Phase 5 | Group G assertions |
| D-5 | Resume semantics | Phase 4 | G `DEEPLINK_BLOCKED` |
| D-6 | Cost model | Phase 4 | Group C metrics |
| D-7 | Fork → upstream flow | Process | — |
| D-8 | Enforce `narrow` | ➕ Phase 5 (sprint 1) | ➕ G `UNNARROWED_RUNS` |
| D-9 | Two "processes" | ➕ Phase 5 | ➕ G `ORPHAN_DOC_RECORDS` |

**Coverage:** of 53 ids, 42 map directly to a gate case in the source and GC-02 indirectly; 3 more
are covered by fixtures added here (SQ-8, D-8, D-9 via `UNNARROWED_RUNS` and `ORPHAN_DOC_RECORDS`);
C-1 needs a new browser case (`XHR_403`); the remaining 6 (C-10, GC-04, GC-06, GC-17, H-4, D-7) are
better covered by unit tests or need no gate.

---

## 8. Consistency notes on the source set

Things found while consolidating that should be corrected in the source files.

1. **`06-roadmap.md` predates CHANGELOG updates 1–4.** SQ-7, SQ-8, GC-20, GC-21, GC-22, D-8, D-9 and
   proving-ground group G have no phase, and its "Suggested first sprint" omits SQ-8 although `05`
   ranks it first. → Folded in here as ➕ rows (§4) and a merged first sprint (§3).
2. **GC-10 (redactor masks the persona id) is in no roadmap phase**, though it has a proving-ground
   case (F). → ➕ Phase 5.
3. **README is stale.** It says "the 19 field issues" (there are 22); its `05` description doesn't
   mention SQ-7/SQ-8; nothing points to D-8/D-9.
4. **GC-15 cross-reference.** GC-15 says it "links to GC-19", but the context (an unactionable item
   re-queued, a wedged run) is GC-18; GC-19 is collapsed content.
5. **Phase 5 row "Expand-collapsed + pre-run cookie" cites GC-18/19.** GC-18 is the wedged run; the
   row most likely means GC-19 only.
6. **Dependency inversions in `06`.** D-5 resume (Phase 4) relies on transit zones from D-2
   (Phase 5); the content-ready wait (Phase 4) and the condition + deadline wait (Phase 5) are the
   same mechanism per SQ-4; D-2 says "decide early" but lands in the last phase. → Resolved in the
   Phase 4 note (§4).
7. **The `06` dependency sketch is ambiguous** about Phase 3: it is drawn into the Phase 2 → Phase 5
   arrow while labelled independent. → Redrawn in §4.
8. **Skill naming.** The README says the folder is produced by the `ground-challenge` skill; the
   CHANGELOG says it is maintained by `ground-challenge-update`. Clarify whether these are two skills
   (generate vs update) and name both in the README.
9. **Group G is cited for SQ-8 / D-8 / D-9 but has no fixture for them.** → ➕ `UNNARROWED_RUNS` and
   `ORPHAN_DOC_RECORDS` (§6.7).
10. **H-4 has no roadmap item.** Fine if it stays a hook example; a "migration inventory" export
    (SPA vs legacy per state) could be a small follow-up feature.
11. **`08` says to wire every roadmap item to a gate case**, but several items have none (§7 gaps).

---

## 9. Anonymisation contract

Everything in `ground-challenge/` — including this document — is scrubbed of client-identifying and
secret material.

**Must never appear**
- Portal / client names (the real portal id, the insurer brand, product names).
- Hostnames and URLs of the real portal, its identity provider, or its asset/CDN hosts.
- The proxy address (host:port) and any internal infrastructure hostnames.
- TLS-inspection / corporate CA certificate file paths or contents.
- User-Agent strings copied from the portal config (they fingerprint the whitelisted browser).
- Persona names, usernames, customer names, contract numbers, dates of birth, or any PII.
- Credentials of any kind (passwords, tokens, PATs, vault contents).
- Copied evidence: screenshots, ARIA snapshots, network-shape dumps, `.sqlite` stores,
  `.excalidraw`/`.svg` wireframes, or run/state ids from the real crawl.
- Issue ids that embed the client — the original dated ids are replaced with neutral `GC-NN`; the
  mapping is intentionally not published.

**Substitution table**

| Real-world thing | Written here as |
| --- | --- |
| the real portal | **Portal-X** / "the legacy insurer portal" |
| the real SSO/OAuth login product (name/host) | **SSO/OAuth identity provider** (generic) |
| the SPA framework the IdP login uses | "a framework-bound SPA login" |
| the legacy page stack | "legacy server-rendered stack (one-big-form style)" |
| the CMS behind some pages | "a legacy CMS" |
| the micro-frontend that mounts the service form | "a late-mounting micro-frontend" |
| the corporate forward proxy host:port | "the corporate proxy" |
| the TLS-inspection CA bundle | "the corporate TLS-inspection CA" |
| real contract/form German labels | kept only where they are generic UI words (e.g. "Weiter" = Next, "Senden" = Send) and carry a classification lesson; never a customer value |
| persona / login names | "a logged-in persona" / "a read-only persona" |

**Why some German words remain.** A few generic German UI verbs (Senden, Absenden, Weiter,
Speichern, Bestätigen) are kept because the lesson itself is about them — the built-in
submit-keyword rules were English/Polish only, so a German "Senden" link was mis-classified as a
read. They are dictionary words, not client data.

**Safe to keep.** The *shape* of a fix (which layer, which function, what it does and why); the
*class* of obstacle without the selector that identifies the client's DOM; generic selectors that
describe web-platform features (`details:not([open])`, `aria-expanded="false"`). A
framework-specific marker (e.g. a legacy stack's hidden server-state field) is generalised to a
`<PLACEHOLDER>`, not named.

---

## 10. Change history

| Date | Change |
| --- | --- |
| 2026-10-15 | Initial generation from the first downstream engagement (Portal-X): C-1…C-10, H-1…H-4, GC-01…GC-19, SQ-1…SQ-6, D-1…D-7; roadmap Phases 0–5; proving-ground groups A–F. All statuses `open` except where the fork already shipped a declarative-config workaround. |
| 2026-10-15 (update) | Field diagnosis of a thinly documented traced process: added GC-20, GC-21 (new Group F), SQ-7, proving-ground group G. Record-only. |
| 2026-10-15 (update 2) | Grounded root cause: the `narrow` step was skipped. Added SQ-8 (top priority) and D-8; re-framed SQ-7 as downstream of SQ-8. Confirmed against the fork's schema and chat orchestrator. |
| 2026-10-15 (update 3) | Environment-consistency hazard: added GC-22 (silent default-env fallback, stray MCP processes) and proving-ground cases `UNSET_ENV`, `ENV_MISMATCH`, `STRAY_MCP_PROCESS`. No data corruption observed. |
| 2026-10-15 (update 4) | Recorded the two-"processes" naming/cross-link concern: added D-9; linked a consequence note from SQ-8. Confirmed against the fork's dashboard code and schema. |
| 2026-10-15 (this document) | Consolidated all eleven files into one roadmap; folded updates 1–4 into the phases (➕ rows); merged the priority orders; added the traceability matrix, two group G fixtures, and the consistency notes. No statuses changed — all items remain open. |

---

## Appendix — source file index

| File | What it holds | Consolidated in |
| --- | --- | --- |
| `README.md` | Folder overview, anonymisation contract summary, reading guide | Intro, §9 |
| `01-core-changes.md` | C-1…C-10 crawler-core changes with cause and lesson | §6.1 |
| `02-hook-patterns.md` | H-1…H-4 hook patterns + the `__name` gotcha | §6.2 |
| `03-trace-driver-pattern.md` | Trace driver + `traces.yaml` (happy-path / validation / loading variants) | §6.3, Phase 2 |
| `04-field-issues.md` | GC-01…GC-22, grouped A–F | §6.4 |
| `05-scan-quality-findings.md` | SQ-1…SQ-8 + scan-quality priority order | §6.5, §2 |
| `06-roadmap.md` | Phases 0–5, dependencies, suggested first sprint | §3, §4 |
| `07-discussion-items.md` | D-1…D-9 | §5 |
| `08-proving-ground-candidates.md` | Groups A–G of local reproduction scenarios | §6.7, §7 |
| `anonymization-note.md` | Scrubbing rules and substitution table | §9 |
| `CHANGELOG.md` | Initial generation + updates 1–4 | §10 |
