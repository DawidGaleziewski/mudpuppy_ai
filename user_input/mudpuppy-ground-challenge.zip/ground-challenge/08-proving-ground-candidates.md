# 08 — Proving-ground candidates

Concrete, **disposable** scenarios to add to `apps/proving-ground` so each lesson is reproducible
locally, without the real (allowlisted, client) site. The downstream work already proved that a
**dependency-free local quirks server** with per-quirk switches can simulate every one of these —
this document is the spec for bringing that into MudPuppy's proving ground.

Each candidate: the switch/scenario, what it reproduces, and the **expected crawler symptom before
the fix** → **after the fix**. "Switch" names are suggestions for the proving-ground config.

> None of these use client data. The quirks are web-platform / framework behaviours (a one-big-form
> page, a late-mounting widget, a blocked CDN) staged on fake hosts like `portal.local`,
> `idp.local`, `cdn.local`.

---

## A. Classification & navigation (highest value: unblocks legacy + SPA)

| Switch | Reproduces | Before → after |
| --- | --- | --- |
| `ONE_BIG_FORM=1` | A page wrapped in a single `<form method="post">` (one-big-form legacy style) with navigation tiles that are `<a>` inside it | Before: tiles classify `mutating`, read-only run refuses them, crawl stuck at the dashboard. After (C-2): tiles classify `read`, crawl proceeds. |
| `SPA_RERENDER=1` | A list that re-renders/re-keys its tiles between observe and act | Before: stale DOM path → `click_failed`. After (C-3): relocated by exact text. |
| `SLOW_TILE_MS=8000` | A role-less tile that becomes actionable after ~8 s | Before: 5 s trial → refused. After (C-4): 15 s budget clicks it. |
| `SELECT_BY_LABEL=1` | A native `<select>` whose option values differ from visible labels | Before: `selectOption(value)` matches nothing. After (C-5): falls back to `{label}`. |
| `JS_POSTBACK=1` | A "Next" link with `href="a javascript: postback"` | Before: `act` crashes `ERR_INVALID_URL`. After (C-7): guarded, treated as non-navigable. |
| `DE_SUBMIT=1` | A German "Senden"/"Weiter" submit link | Before: classified `read`, read persona posts the form. After (GC-14): DE submit lexicon classifies it. |

## B. Content readiness (stops junk evidence)

| Switch | Reproduces | Before → after |
| --- | --- | --- |
| `LATE_MFE_MS=1500` | A service form body mounted by a micro-frontend ~1.5 s after the shell settles | Before: click into nothing / empty-shell screenshot. After (H-3): wait for the mount point before acting/capturing. |
| `COLLAPSED=1` | Links/fields inside closed `<details>` and `aria-expanded="false"` accordions | Before: snapshot/screenshot miss them. After (H-2): expanded (hidden-only, submit suppressed) before observe. |
| `COLLAPSED_DEFAULT_OPEN=1` | Some sections already open by default | Guard case: a naive "click all toggles" *collapses* these (links drop ~20→2). After (H-2): only genuinely hidden panels are clicked. |
| `CDN_CSS=1` + `BLOCK=cdn.local` | Stylesheet from a blocked CDN host | Before: unstyled page + unstyled screenshot. After (GC-13): `asset_check:failed` warning + recapture when assets load. |
| `FLAG_COOKIE=1` | A list hidden unless a feature cookie is set | Before: empty "nothing to show". After (H-1): cookie seeded, full list renders. |

## C. Frontier efficiency & wedged runs (biggest cost win)

| Switch | Reproduces | Before → after |
| --- | --- | --- |
| `HIDDEN_ITEMS=1` | Hidden/`display:none` clickables in the DOM | Before: issued, refused, re-issued (churn). After (GC-16): never issued. |
| `JS_POPUP=1` | A `href="javascript:window.open(...)"` link | Before: `act` → `INTERNAL`, item re-handed, `finish_run` → `FRONTIER_NOT_EMPTY` (wedged). After (GC-15/18): recognised non-navigable, recorded + retired, run completes. |
| `SHARED_NAV=1` | A global nav repeated on every page | Before: re-walked on each state. After (GC-16): deduped. |
| `MANY_READ_LINKS=40` | A page with many read-only links | Before: one turn per link. After (GC-16): server-side batch drain for read-only maps. |

Metric to assert on these: **turns per new state** below a target; **refusal rate** below a target;
run reaches `completed` (no `FRONTIER_NOT_EMPTY`).

## D. Auth, SSO & redirect chains (the design-heavy set)

| Switch | Reproduces | Before → after |
| --- | --- | --- |
| `SPA_LOGIN_CHUNKS=60` | Login form renders only after ~60 chunked requests | Before: at polite rate, `control_not_found`. After (GC-08/D-2): wait derived from limiter / `login.wait`. |
| `BOUND_INPUTS=1` | Framework-bound login inputs (model, not DOM value) | Before: bare `.fill()` → submit rejected, `unknown`. After (C-6): events dispatched, model commits. |
| `AUTH_HOPS=2`, `HOP_DELAY_MS=1000` | Slow multi-hop 302 chain after an SPA callback, cross-host | Before: success checked on the IdP host mid-chain → `failed/unknown` lockout though the user lands on the dashboard. After (D-2): condition wait + `pending` + transit zone. |
| `HASH_ROUTE=1` | `#/login` → `#/redirecting` URL change with no load event | Before: nothing to wait on. After (D-2): condition-based wait. |
| `IDP_ERROR_FIRST_N=1` | Transient IdP error page, message rendered by script after ~3 s | Before: blank snapshot/screenshot, `control_not_found`; next run fine. After (GC-11): wait for error text, classify transient error, retry. |
| `WAF_UA=1` | IdP/WAF 403 for a non-browser UA before the form renders | Before: 403, no form. After (GC-07): realistic UA from config; doctor `waf.user-agent`. |

## E. Corporate network & environment (first-start pain)

| Switch | Reproduces | Before → after |
| --- | --- | --- |
| `ALLOWLIST=1`, `PROXY_SOURCE=127.0.0.2` | Site reachable only from the proxy's egress IP | Before: `RUN_STOPPED` 403, 0 states. After (GC-03/05): `network.proxy` routes via the allowlisted egress. |
| `PROXY_ONLY_HOSTS=1` | Fake hosts resolvable only through the proxy; `HTTPS_PROXY` env not honoured by the gate | Before: DNS error / 403 with env var only. After (GC-03): `network.proxy` in the portal file. |
| `BLOCK=cdn.local` | Proxy refuses a third-party host | Before: half-rendered page, fewer actions. After (GC-12): per-host routing (bypass direct) + CA trust. |
| `PROD_LOOKING_HOST=1` | A production-looking hostname for a dev site | Before: `ENV_GUARD_REFUSED` with a non-prod env. After (D-1): freeform env + `production:false` flag. |
| `ROBOTS=deny` | `Disallow: /` on a dev tier | Before: refused navigations. After (GC-01): `robots: ignore` tied to non-prod flag. |
| `STRAY_ENV_SLUG=1` | A typo'd `PATHFINDER_ENV` | Before: silent stray `<name>.sqlite`, scattered data. After (C-8): rejected with a helpful message. |
| `UNSET_ENV=1` | `PATHFINDER_ENV` unset / ambiguous when the MCP server starts | Before (GC-22): silently defaults to a tier (now a non-prod client tier), mismatching the dashboard/chat. After: server refuses to start (or demands an explicit env). |
| `ENV_MISMATCH=1` | MCP server on env A while the dashboard/chat serve env B | Before (GC-22): confusing cross-env calls, risk of writing the wrong store. After: a start-up env-agreement check warns loudly; current env shown in every result/header. |
| `STRAY_MCP_PROCESS=1` | A second MCP server from another checkout running on the same data dir | Before (GC-22): calls answered by an unrelated server on a different env. After: a per-data-dir PID/lock warns about the stray instance. |

## F. Privacy / redaction

| Switch | Reproduces | Before → after |
| --- | --- | --- |
| `PERSONA_ID_EQUALS_LOGIN=1` | Persona id equals the login name | Before: `runs.persona_id = [secret]`. After (GC-10): redact credential values, keep the id readable. |

---

## G. BA run selection & documentation quality (recorded 2026-10-15)

These are **documentation-pipeline** scenarios, not browser quirks — stage them with a small fixture
store (a disposable set of recorded runs for one fake process) rather than a live crawl.

| Fixture | Reproduces | Before → after |
| --- | --- | --- |
| `RICH_INTERRUPTED_RUN=1` | For one process: a `goal_reached` 6-step run **and** an `interrupted` 12-step run with more screenshots | Before (GC-20): BA documents the thin completed run, ignores the rich interrupted one. After: BA selects by richness and documents the interrupted run with an honest partial `observed_extent`. |
| `DUP_VARIANT_RUNS=1` | Several near-duplicate variant runs for the same process | Before (SQ-2/SQ-7): duplicates crowd out the good run; "one screen twice". After: de-dup / mark-usable so the rich run wins. |
| `MULTISTEP_PROCESS=1` | A process with N steps + 2 validation-error states | Before (GC-21): one `screen_region` cited for the whole record; most steps show no screenshot. After: a quality check flags steps/variant-states lacking a cited region; BA cites one per step/state. |
| `DEEPLINK_BLOCKED=1` | A process reachable only by UI navigation; a deep-link lands on a generic error-code page | Before (SQ-5/SQ-7): deep-link → error page → 1–2 step `map_only` stub. After: reached by navigation from a known node (not deep-link); real steps/screens captured. |

Assertions for group G run against the **exported documentation**, not the browser: e.g. every
`use_case` step cites a `screen_region`; the richest trace per process is the one documented; no two
`screen` records share a route template with near-identical layout.

## How to use this

1. Extend the proving-ground backend with these switches (the fork's `quirks-server.mjs` is a
   dependency-free reference implementation of the whole set — re-implement, don't copy client
   config).
2. Add a **gate case per candidate** in the quality-gate suite, asserting the "after" symptom.
3. Wire each roadmap item (`06`) to its gate case so a regression (or an un-landed fix) fails the
   gate.
4. Keep every scenario **disposable and client-free** — fake hosts, synthetic data, generic DOM.

The win: every lesson from Portal-X becomes a **repeatable local test**, so the fixes can be landed
upstream with confidence and the next engagement starts from a hardened base.
