# 06 — Roadmap

A phased plan to bring the real-world lessons upstream into MudPuppy. Ordered by leverage: earlier
phases unblock later ones. Each item lists the source (`C-*` core change, `GC-*` field issue, `SQ-*`
finding, `H-*` hook pattern), effort (S/M/L), and acceptance criteria. Phases are roughly
independent except where noted.

> This is a proposal distilled from the field work; it does not replace `roadmap.md` at the repo
> root. Fold the accepted items into that roadmap with proper spec ids.

---

## Phase 0 — Land the clearly-correct core fixes (quick wins) · effort M

Bring in the fixes that are correct as-is and unblock whole classes of portals.

| Item | Source | Effort | Acceptance |
| --- | --- | --- | --- |
| Scope 403/429 hard-stop to the main-frame document | C-1 | S | A background XHR 403 does not stop the run; a 403 *page* still does. Unit + proving-ground case. |
| Anchor vs form-POST classification (`tag` field) | C-2 | M | On a one-big-`<form>` legacy page, navigation tiles classify `read` and a read-only run clicks them. Gate case. |
| Anchor text-first locator in SPA | C-3 | S | A re-rendering list tile is relocated by text after re-render; no `click_failed`. |
| Wider actionability budget for role-less tiles | C-4 | S | A tile that settles in 6–10 s is clicked, not refused. |
| `selectOption` label fallback | C-5 | S | A `<select>` option is chosen by visible label. |
| Framework-bound login fill (`enterBound`) | C-6 | S | A data-bound login form submits; model receives the value. Proving-ground SPA-login case. |
| Non-http href guard (`isHttpUrl`) | C-7 | S | A `javascript:`/`mailto:` href does not crash `act`. Unit. |
| `api_endpoint` record kind + element `behaviour` | C-10 | M | BA can create an `api_endpoint` record from a network shape; export renders it. Schema + render tests. |
| Multi-locale submit keyword dictionary (DE) | GC-14 | S | A German "Senden" link classifies as a submit; read persona does not click it. |

---

## Phase 1 — Environment model done right (not re-hardcoded) · effort M · ⚠️ supersedes C-9

| Item | Source | Effort | Acceptance |
| --- | --- | --- | --- |
| Freeform environment label + per-env `production: true|false` | C-9, GC-01, D-1 | M | A portal can declare any env name and flag it non-production; no code change to add a tier. |
| Single source of truth for environments (collapse the duplicated enum) | C-9 | M | One definition; config/vault/store/mcp import it. |
| Production-address guard keys off the declared flag (or explicit host allowlist), not a hostname regex | GC-01, D-1 | M | A dev host that doesn't match the old regex is *not* gated as production when flagged non-prod. |
| `KNOWN_ENVIRONMENTS`-style guard against stray stores, derived from the declared envs | C-8, SQ-1 | S | An undeclared slug is rejected (with a helpful message); readers of existing files still open them. |
| **Mutation tests** around env/run routing & prod gating | GC (to-improve) | M | A mutant that inverts prod gating or drops an env label is killed. |

---

## Phase 2 — Trace-driver: force form processes to completion · effort L · depends on Phase 0 (C-5/6/7)

The highest-value feature for "finish a form process".

| Item | Source | Effort | Acceptance |
| --- | --- | --- | --- |
| `traces.yaml` schema in `config` (validated), with `to_be_discovered` stubs | 03 | M | A bad traces file is rejected naming the problem; stubs are skipped. |
| `pnpm trace <portal> <id|all> <persona> --env <env> [--variant]` command driving `mode:"trace"` | 03 | L | Headless, bounded; one `processes` row + ordered `process_steps` per variant. |
| Variants: happy-path / validation-error / loading | 03 | M | Validation variant records the error message(s) as rule candidates; loading state captured or honestly "none". |
| Privilege decides submit vs boundary | 03 | S | High-privilege persona executes submit and records the result; lower ceiling stops at `boundary_reached`. |
| Synthetic-data enforcement on scrub portals | 03 | S | Suspected PII in a trace value is rejected. |
| Dashboard Process tab renders each variant as a flowchart with the start node marked | 03 | M | Each variant visible as `flowchart TD` with a `start([...])`. |
| BA follow-up loop: named process → stub → map discovers → steps filled → driver → use-case | 03, SQ-6 | M | The map→document→trace→document loop runs end-to-end on the reference portal. |

---

## Phase 3 — First-start "doctor" + agnostic network config · effort L

Removes most corporate-environment first-day pain.

| Item | Source | Effort | Acceptance |
| --- | --- | --- | --- |
| `network.proxy { server, bypass, enabled }` honoured by the request gate | GC-03/05 | M | A proxy-only portal is reachable; bypass hosts go direct. Proving-ground allowlist case. |
| Per-host routing (proxy vs direct) + corporate CA trust (`network.ca_certificates`) | GC-12 | M | Portal host via proxy, asset host direct; TLS-inspected direct host trusts the configured CA. |
| Asset-health check (`network.asset_check`) + optional recapture | GC-13, SQ-4 | M | A blocked key asset emits a warning + `render_warnings`; screenshot recaptured once assets load. |
| Doctor registry (id, applies_when, depends_on, probe, signature, fix, inputs) | GC-02/04/06/07 | L | New checks/fixes add via the registry with no core change; first run prints a diagnosis. |
| WAF-UA + native-toolchain + PAC checks as registry entries | GC-04/06/07 | M | Each prints the cause and the one-line fix. |

---

## Phase 4 — Frontier efficiency & resume · effort L · biggest cost/quality win

| Item | Source | Effort | Acceptance |
| --- | --- | --- | --- |
| Don't issue hidden/unclickable items | GC-16, SQ-3 | M | Hidden items never reach the agent; refusal rate drops sharply (measure on a gate). |
| Carry `next` in refusal results | GC-16 | S | A refusal advances to the next frontier item in the same turn. |
| Retire an unactionable item (record, don't re-queue) so `finish_run` can complete | GC-15/18, SQ-3 | M | A `javascript:` popup item is recorded + retired; the run completes with a documented remainder. |
| Server-side batch drain for read-only map runs | GC-16 | L | A read-only map drains many read items per server round-trip; turns-per-state falls. |
| Dedup shared navigation actions across states | GC-16, SQ-2 | M | The global nav isn't re-walked on every page. |
| Cost per run in the dashboard (populate `agent_turns`) | GC-16 | S | Each run shows its turn/credit cost. |
| **Resume map from a known node** (seed frontier from a state's unexplored actions; reuse states by fingerprint) | SQ-5, D-5 | L | Mapping a subtree from a chosen node continues the existing graph instead of starting fresh. |
| Content-ready wait before evidence capture | SQ-4, H-3 | M | Screenshots/snapshots taken only after a content-ready signal, not just network idle. |

---

## Phase 5 — Auth/transit zones & BA quality · effort L · depends on Phase 4

| Item | Source | Effort | Acceptance |
| --- | --- | --- | --- |
| One condition-based wait with a progress-extending deadline (login, navigate, act) | GC-08/09, D-2 | L | A slow multi-hop login succeeds; the wait extends while there is progress. |
| `pending` outcome (not `failed`) for ambiguous auth | GC-09, D-2 | M | An in-progress redirect chain yields `pending`, not a lockout. |
| Per-portal transit zones (poll, don't record intermediate hops) | GC-09, D-2 | M | Cross-host login hops aren't recorded as states; the final landing is. |
| Login success/failure markers + late-error handling | GC-09/11 | M | A transient IdP error is distinguished from `control_not_found`; evidence captured after the error renders. |
| Expand-collapsed + pre-run cookie as declarative config | H-1/H-2, GC-18/19 | M | Collapsed content revealed (hidden-only, submit-suppressed); flag cookie seeded. |
| Documentation quality gate | SQ-6, D-4 | M | A doc set with screens but zero requirements/rules, or duplicate screens sharing a route template, is flagged. |
| Credential bulk import | GC-17 | M | Many personas' creds imported from a refs file; no plaintext on argv. |
| Hook-authoring docs incl. the `__name`/esbuild gotcha (or a `NAME_SHIM`) | H-* | S | In-page hooks documented; the gotcha has a documented remedy. |

---

## Dependency sketch

```
Phase 0 (core fixes) ──► Phase 2 (trace driver)  ──► Phase 5 (BA quality)
        │                                   ▲
        └──► Phase 1 (env model) ──► SQ-1   │
Phase 3 (doctor/network) ───────────────────┘ (independent, enables corporate portals)
Phase 4 (frontier/resume) ──────────────────► Phase 5
```

## Suggested first sprint

Phase 0 in full (unblocks legacy + SPA portals and is low-risk), plus the two Phase 4 quick wins
(`next` in refusals; retire unactionable items) to stop wedged runs immediately. Then Phase 2 for
the form-completion goal.
