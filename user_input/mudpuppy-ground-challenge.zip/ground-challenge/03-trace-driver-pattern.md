# 03 — Trace-driver pattern: forcing a form process to completion

This addresses the pain you called out as **most important**: *"I have big issues forcing the
scanner to actually finish a form process."* The fork solved it with a reusable **trace-driver**
layer on top of `mode:"trace"`. Here is the pattern, anonymised.

## The problem

In `map` mode the crawler explores breadth-first and stops at the first irreversible action. That is
right for discovery, but it means a **multi-step form is never driven to its end** — you get the
first page of a form and nothing after. Asking the agent to "just finish the form" is unreliable:
it wanders, re-maps, or stops at a boundary.

## The solution: a declarative, per-portal trace catalogue + a driver

Two pieces:

### 1. `portals/<portal>/traces.yaml` — one entry per named process

A trace pins a process to a **start node** (`start_url`) and lists the **ordered field
interactions**, the **advance** controls (to move a multi-page form forward), and the final
**submit** control. Each trace runs one or more **variants**:

- **happy-path** (`expect: proceed`) — valid input; the form must advance past submit.
- **validation-error** (`expect: validation_error`) — a required field omitted; the form must
  refuse and the driver **scrapes and records the exact error message(s)**.
- **loading** — whatever pending state (spinner / disabled button / interstitial) appears between
  submit and result is captured (honestly "none observed" for a classic full-page postback).

```yaml
traces:
  - id: send-message
    name: Send a message
    goal: Document the general contract message form — happy path, validation errors, loading state.
    start_url: https://<portal-host>/<path-to-form>      # anonymise host+path upstream
    steps:
      - match: "<contract select label>"
        kind: select
        value: "<visible option label>"   # label, not internal value (see C-5)
        intent: Choose which contract the message is about
      - match: "<category>"
        kind: check
        intent: Choose the message category
      - role: textbox
        kind: fill
        value: "Synthetic test message for process documentation. No real data."
        intent: Enter the free-text message
    advance: ["Next"]          # generic: the "move forward" control
    submit: "Send|Submit"      # the irreversible action
    variants:
      - { id: happy-path, expect: proceed }
      - { id: missing-contract, expect: validation_error, steps: [ { role: textbox, kind: fill, value: "…", intent: "message only, contract left unset" } ] }
      - { id: empty-message,    expect: validation_error, steps: [ { match: "<contract>", kind: select, value: "<label>", intent: "contract only, message empty" } ] }
```

**Stubs**: a process can be listed with `to_be_discovered: true` and no steps, so the **full
catalogue of intended processes lives from day one**; the driver skips stubs until a map discovers
the page and the steps are filled in. This is a neat way to track "processes we know exist but
haven't driven yet".

### 2. `run-trace` driver — walks the trace over the real MCP server

A dependency-free driver script reads `traces.yaml`, logs in as the persona (vaulted creds — never
seen), navigates to `start_url`, fills each field with **synthetic** values, clicks `advance` then
`submit`, and lets the MCP server record a `processes` row + ordered `process_steps`.

**Privilege decides submit vs boundary** (the safety model stays intact):

- A **high-privilege** persona (ceiling `external-side-effect`) → the submit is executed and the
  trace records the **result page**. ("Go through the whole process and observe the result.")
- A **lower-ceiling** run → the submit is refused and the trace stops at `boundary_reached` (what
  happens after submit is honestly "not observable"). Lower `max_action_class` to get the safe stop.

Synthetic-data discipline: values must be synthetic (emails on `.invalid`/`.test`/`.example`); the
server rejects suspected PII on portals that scrub.

## Why this is the right shape

- **Deterministic**: the form is driven the same way every run; no agent wandering.
- **Variant-first**: happy path, validation and loading are *separate* inspectable runs, each its
  own `processes` row — exactly what a BA needs for a use-case (main flow + exception flows).
- **Declarative**: adding a process is a `traces.yaml` entry, no code.
- **Safe**: the persona ceiling, not the driver, decides whether the real submit fires.

## What the core needed to support it (already in `01-core-changes.md`)

- **C-7** `isHttpUrl` guard — a legacy `javascript:` postback "Next" link no longer crashes
  `act`.
- **C-5** `selectOption` label fallback — the trace author gives the visible label, not the
  internal value.
- **C-6** framework-bound fill — the fields actually receive the value in a reactive form.

## Upstream recommendation

Bring the trace-driver concept into MudPuppy proper as a **first-class feature**, not a side script:

1. `traces.yaml` schema in `config` (validated like portal/persona files), with `to_be_discovered`
   stubs.
2. A `pnpm trace <portal> <trace-id|all> <persona> --env <env> [--variant …]` command that drives
   `mode:"trace"` runs headless, bounded (timeout), one `processes` row per variant.
3. Record validation messages as **business-rule candidates** (they already are in the fork) and
   render each variant as a flowchart in the dashboard Process tab, with the start node marked.
4. A BA follow-up loop: the BA names processes → stubs appear in `traces.yaml` → a map discovers the
   page → steps filled → driver runs the variants → BA turns them into use-case records. This closes
   the "map → document → trace → document" loop the README already promises.

This is the single highest-value item for your stated goal of **finishing form processes**. See
`06-roadmap.md` Phase 2.
