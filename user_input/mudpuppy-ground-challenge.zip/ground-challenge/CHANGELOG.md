# ground-challenge changelog

Newest first. Each entry names the ids touched and the nature of the change (added / status /
superseded). Maintained by the `ground-challenge-update` skill.

## 2026-10-15 (update 4)
- Recorded a product UX/architecture concern: "processes" means two different pipeline layers — the
  reconciled model (`ba_processes`/`process_variants`, Processes tab, keys `PRC-*`) vs the written
  SRS (`doc_records` process/use_case, Docs section, keys `PROC-*`/`UC-*`) — with no 1:1 cross-link.
  Record-only.
- Added discussion item D-9 (name collision + model↔docs cross-link + make `document` run over the
  reconciled model) in `07`; linked a consequence note from SQ-8 in `05`.
- Confirmed against the fork's dashboard code (`queries_processes` / Docs sections) and schema
  (`ba_processes` key `PRC-*`; docs-model `process`→`PROC`, `use_case`→`UC`). No statuses flipped.

## 2026-10-15 (update 3)
- Recorded an environment-consistency hazard observed in operation: MCP servers kept running on a
  default tier (env A) while the dashboard/chat served the working tier (env B), because `mcp.json`
  pins `PATHFINDER_ENV` to a default and reverts to it after a session; compounded by stray MCP
  processes from another checkout. No data corruption observed. Record-only.
- Added field issue GC-22 (silent default-env fallback → MCP on the wrong environment) in `04`
  Group A, cross-linked to C-8 / C-9 / D-1 / GC-01.
- Added proving-ground cases `UNSET_ENV`, `ENV_MISMATCH`, `STRAY_MCP_PROCESS` to `08` group E.
- No statuses flipped (all open).

## 2026-10-15 (update 2)
- Recorded the **grounded root cause** behind the thin/duplicate process docs: the `narrow`
  (reconciliation) pipeline step was skipped, so the BA documented raw, ungrouped runs. Record-only.
- Added scan-quality finding SQ-8 (narrow step skipped — reconciliation is the chat orchestrator's
  job, not the BA's) in `05`, and promoted it to the top of the priority order.
- Added discussion item D-8 (enforce `narrow` before `document`; should the BA refuse un-narrowed
  input?) in `07`.
- Re-framed SQ-7 as downstream of SQ-8 (BA adherence/robustness vs the orchestration gap).
- Confirmed against the fork's schema (pipeline step enum scan/map/narrow/document/amend;
  grouping_suggestions / ba_processes / process_variants tables) and chat orchestrator
  (process-suggestions / process-service). No statuses flipped (all open).

## 2026-10-15 (update)
- Recorded a field diagnosis (BA documented a traced form process thinly despite rich evidence).
  Record-only; not yet reproduced or fixed.
- Added field issues GC-20 (BA skips interrupted-but-rich trace runs — "completed-only" rule) and
  GC-21 (BA under-cites screen regions, one per record not per step/state) in `04`, as new Group F.
- Added scan-quality finding SQ-7 (rich evidence exists but the BA documents from the wrong runs) in
  `05`, and added it to the priority order.
- Added proving-ground group G (BA run selection & documentation quality) in `08`.
- Cross-referenced to SQ-2/SQ-5/SQ-6 and D-4; no statuses flipped (all open).

## 2026-10-15
- Initial generation from the first downstream engagement (Portal-X).
- Added core changes C-1…C-10, hook patterns H-1…H-4, field issues GC-01…GC-19,
  scan-quality findings SQ-1…SQ-6, discussion items D-1…D-7.
- Roadmap (`06`) Phases 0–5 and proving-ground candidates (`08`) groups A–F created.
- All statuses `open` except where the fork already shipped a declarative-config workaround
  (noted inline in `04`).
