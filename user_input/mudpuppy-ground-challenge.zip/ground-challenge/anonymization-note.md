# Anonymisation note

Everything in `ground-challenge/` is scrubbed of client-identifying and secret material. This note
records the rules so the result can be audited and the skill can enforce them.

## Must never appear

- **Portal / client names** (the real portal id, the insurer brand, product names).
- **Hostnames and URLs** of the real portal, its identity provider, or its asset/CDN hosts.
- **Proxy address** (host:port) and any internal infrastructure hostnames.
- **TLS-inspection / corporate CA certificate file paths** or contents.
- **User-Agent strings** copied verbatim from the portal config (they fingerprint the browser the
  client whitelisted).
- **Persona names, usernames, customer names, contract numbers, dates of birth**, or any PII.
- **Credentials** of any kind (passwords, tokens, PATs, vault contents).
- **Copied evidence**: screenshots, ARIA snapshots, network-shape dumps, `.sqlite` stores,
  `.excalidraw`/`.svg` wireframes, or run/state ids from the real crawl.
- **Issue ids that embed the client** — the original `BI-YYYYMMDD-NN` ids are replaced with neutral
  `GC-NN` ids here; the mapping is intentionally not published.

## Substitution table

| Real-world thing | Written here as |
| --- | --- |
| the real portal | **Portal-X** / "the legacy insurer portal" |
| the real SSO/OAuth login product (name/host) | **SSO/OAuth identity provider** (generic) |
| the SPA framework the IdP login uses | "a framework-bound SPA login" |
| the legacy page stack | "legacy server-rendered stack (legacy server-rendered, one-big-form style)" |
| the CMS behind some pages | "a legacy CMS" |
| the micro-frontend that mounts the service form | "a late-mounting micro-frontend" |
| the corporate forward proxy host:port | "the corporate proxy" |
| the TLS-inspection CA bundle | "the corporate TLS-inspection CA" |
| real contract/form German labels | kept **only** where they are generic UI words (e.g. "Weiter"=Next, "Senden"=Send) and carry a classification lesson; never a customer value |
| persona / login names | "a logged-in persona" / "a read-only persona" |

## Why some German words remain

A few generic German UI verbs (Senden, Absenden, Weiter, Speichern, Bestätigen) are kept because the
*lesson itself is about them* — the built-in submit-keyword rules were English/Polish only, so a
German "Senden" link was mis-classified as a read. These are dictionary words, not client data.

## What is safe to keep

- The **shape** of a fix (which layer, which function, what it now does and why).
- The **class** of obstacle (a late-mounting micro-frontend, a collapsed accordion, a framework-
  bound input) without the selector that identifies the client's DOM.
- Generic selectors that are not client-specific and not framework-identifying
  (`details:not([open])`, `aria-expanded="false"`) — these describe web-platform features, not the
  client. A framework-specific marker (e.g. a hidden server-state field of a legacy stack) is
  generalised to a `<PLACEHOLDER>`, not named.
