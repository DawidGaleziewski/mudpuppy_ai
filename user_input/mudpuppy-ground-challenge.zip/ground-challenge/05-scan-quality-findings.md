# 05 — Scan-quality findings

The quality problems you observed in the downstream fork's runs, each tied to concrete evidence and
a root cause. These are **assessment findings**, not fixes — the fixes/directions live in `06` and
`08`. Evidence is described, never copied.

---

## SQ-1 — Scattered scans / data split across stores 🟠

**Observed**: more than one `*.sqlite` store sat side by side under the data dir — the two intended
tier stores **plus** extra ones (a leftover `sandbox` store, and a stray store whose name looked
like a typo'd env, now deleted). Crawl data was split across them, so "where did my run go?" was
ambiguous and a map looked like it had fewer states than it did.

**Root cause**: `dbPathFor()` accepted **any** slug and silently created `<name>.sqlite`. A stray
`PATHFINDER_ENV` (a typo, or a one-off tool) spawned a parallel store that real crawl data leaked
into. See **C-8/C-9**.

**Direction**: the `KNOWN_ENVIRONMENTS` guard (C-8) stops the stray store; the real fix is the
freeform-env + `production` flag with **one** source of truth (C-9, D-1). Add a dashboard view that
lists every store and its run count so scatter is visible.

---

## SQ-2 — Duplicate / repeated screens, same thing re-scanned 🟠

**Observed**: the same screen recorded more than once; the crawl appeared to **re-visit** states
instead of pushing into new ones. In documentation this surfaced as "one screen twice".

**Root causes (two, compounding)**:
1. **State identity in a re-rendering SPA** — a page that re-renders/re-keys produces slightly
   different snapshots, so the fingerprint can treat one screen as several (and, conversely, the
   stale-locator problem C-3 made the crawler *fail* to move, then retry the same place).
2. **Frontier issuance** — hidden/unclickable items (GC-16) got handed out, refused, and re-handed,
   so turns were spent re-touching the same node rather than advancing.

**Direction**: C-3 (stable text locators) reduces the re-render churn; GC-16/GC-18 fixes
(don't issue hidden items, carry `next` in refusals, retire unactionable items) stop the re-touch
loop. A **stability measure between two runs** (the repo already has a `stability` tool) should be
run and watched. Consider surfacing a "duplicate-screen" warning when two states share a route
template and near-identical layout.

---

## SQ-3 — Frontier not advancing; re-scanning instead of pushing 🟠

**Observed**: runs that spent most of their turns on `click_failed` + `get_next_frontier_item`
without reaching new states; several runs never completed (wedged in `running`).

**Evidence (from the issue log)**: in one logged-in map, **148 of 165 turns** were a refusal + a
frontier poll; **45%** of a day's tool calls were in runs that never completed; several runs stuck
with `FRONTIER_NOT_EMPTY`.

**Root cause**: the frontier handed out items that could not be acted on (hidden, unclickable,
`javascript:` popups — GC-15), refusals didn't advance to the next item, and unactionable items
were re-queued forever (GC-18) so `finish_run` could never succeed.

**Direction** (highest leverage, `06` Phase 4): don't issue hidden/unclickable items; **retire** an
item that can't be acted on (record it, don't re-hand it); put `next` in every refusal result;
server-side **batch drain** for read-only map runs; **dedup shared nav actions** across states so
the global nav isn't re-walked on every page.

---

## SQ-4 — Screenshots of not-fully-loaded pages 🟠

**Observed**: screenshots captured before the page finished — unstyled pages, or a shell without its
late-mounted form/content.

**Root causes (two)**:
1. **Blocked assets** — a stylesheet from a blocked CDN host never loaded, so the screenshot is
   unstyled (GC-13).
2. **Late content** — "network idle / load" fired before a **micro-frontend mounted** its body
   (H-3), so the screenshot shows an empty shell; and a transient IdP error text rendered *after*
   capture, giving a blank screenshot (GC-11).

**Direction**: an **asset-health check** that warns on failed key assets and **recaptures** once
they load (GC-13); a **content-ready** condition (not just network idle) before capture — the same
condition-based wait as H-3/D-2; capture evidence only after the "ready" signal.

---

## SQ-5 — "Scan from a point in the graph" starts a fresh crawl 🟠

**Observed**: asking to scan only *part* of a process from a chosen node seemed to **start over**
instead of continuing from that node's recorded state.

**What actually exists**: `start_run` already supports `focus { start_url, only_domains,
only_paths, exclude_paths }`, and the trace-driver pattern (`03`) uses `focus.start_url` to pin a
run to a node. So the capability is there — but:

**Gaps that make it feel like "starting fresh"**:
1. A **map** run from a focus still **re-discovers** the subtree from scratch (new states), rather
   than attaching to the existing graph — there's no "resume mapping from this known state and only
   expand its unexplored frontier".
2. `focus.only_paths` applies to **every** request including the login redirect, so a login-gated
   start node needs `only_paths` omitted (documented in the fork's traces.yaml) or the login hops
   get fenced out — easy to get wrong and looks like a failed/fresh run.

**Direction**: a true **"resume from node"** mode for maps — seed the frontier from a chosen
existing state's unexplored outgoing actions, reuse recorded states by fingerprint, and don't
re-walk known nav. Document the `focus` + login-redirect interaction. → `06` Phase 4, `07` D-5.

---

## SQ-6 — BA documentation is thin / low quality 🟠

**Observed**: lots of raw captured data but weak documentation — a screen recorded twice, **no
business requirements**, generally "garbage in, garbage out".

**Root causes (layered)**:
1. **Input quality** — SQ-2 duplicate screens feed the BA duplicate inputs; it faithfully documents
   the duplication ("one screen twice").
2. **Shallow traversal** — forms never driven to completion (`03`) means no process/use-case
   evidence, so the BA has nothing to turn into requirements or business rules; it stops at screens.
3. **Guidance** — the BA produced screens/data items but few **requirements/business rules/
   use-cases**. These need (a) process evidence from traces, and (b) the analysis passes actually
   run (capabilities → requirements → rules), with validation messages captured as rule candidates
   (the trace driver does this; a map alone doesn't).

**Direction**:
- Fix the inputs first (SQ-2, SQ-3): clean, de-duplicated states.
- Feed the BA **process evidence** via the trace-driver loop (`03`) so it can write use-cases
  (main/alternate/exception flows) and promote validation messages to **business rules**.
- The newer BA guidance already pushes on requirement/rule quality and process scoring — pair it
  with the `api_endpoint` kind (C-10) so backend contracts are documented too.
- Add a **documentation quality gate**: fail/flag a doc set that has screens but zero requirements/
  rules, or duplicate screens sharing a route template. → `06` Phase 5, `07` D-4.

---

## SQ-7 — Rich evidence exists but the BA documents from the wrong runs 🟠

> Recorded from a field diagnosis on 2026-10-15 (not yet reproduced/fixed).

**Observed**: a traced form process came out thin — "only one step", or just the last-step
screenshot, or none — while the database held a much richer trace (more steps, more screenshots) for
the same process. Separately, the deep-linked variants of other processes landed on a generic error
page (an error-code screen) and were honestly documented as 1–2 step `map_only` stubs.

**Root causes (three, compounding)**:
1. **Run selection by status, not richness** — the richest trace runs were **interrupted**, and the
   BA's "use every *completed* run" rule skipped them, documenting from the thinner completed/
   abandoned runs instead (GC-20).
2. **Under-citation** — the BA cited one `screen_region` per record, so most steps/variant states
   showed no screenshot/wireframe (GC-21).
3. **Messy inputs** — several near-duplicate variant runs plus deep-link-blocked stubs crowded the
   good evidence; and a process reachable only via UI navigation was deep-linked, hit an error page,
   and became a stub (overlaps SQ-2 duplicates and SQ-5 "scan from a point starts fresh / deep-link
   fenced out").

**Why re-running the same BA won't fix it**: the richest run stays interrupted (so the BA keeps
skipping it) and the duplicates keep producing thin pages. The fix is a **coordinated data-hygiene +
run-selection change**, not another BA pass on the same inputs.

**Direction**: (a) select trace runs by evidence richness/outcome, allowing interrupted runs with an
honest partial `observed_extent` (GC-20); (b) enforce one `screen_region` per step/variant state
(GC-21); (c) de-dup/mark-usable runs so the rich one isn't crowded out; (d) reach UI-only processes
by **navigation, not deep-link**, so they don't degrade to error-page stubs (ties to SQ-5 and the
trace-driver `focus.start_url` + login-redirect interaction). → `04` GC-20/GC-21, `06` Phase 5,
`07` D-4; proving-ground `08` group G.

---

## SQ-8 — The reconciliation ("narrow") step was skipped, so the BA documented un-grouped runs 🔴

> Recorded from a grounded field diagnosis on 2026-10-15 (record-only). This is the **deeper root
> cause** behind SQ-7 / GC-20 / GC-21 — not a BA defect but a **skipped pipeline stage**.

**Observed**: one journey had ~16 raw trace runs that were never merged; the BA produced one thin
process doc per leftover run — duplicates, one-step stubs, inconsistent screenshots.

**How the pipeline is *supposed* to work** (confirmed in the fork's schema + how-to-use): a 5-step
workflow **scan → map → narrow → document → amend** (the `pipeline` step is a CHECK-constrained enum
with exactly these values). Crucially:
- **States are deduped by fingerprint, never overwritten.** Observations hold many sightings of a
  few distinct states across runs; the same screen in many runs is **one** state linked to all of
  them. A validation error is recorded as **its own extra step** whose `state_after` is the error
  state (e.g. "heading count changed 4→5"). Error paths are extra steps/states, by design.
- **`narrow` is where reconciliation happens**, and it is **owned by the chat orchestrator**
  (`apps/chat` `process-suggestions` / `process-service`), **not the BA**. It suggests groupings
  (sets of runs/screens that look like one process); accepting one creates a single process with
  **variants as branches** (happy-path / missing-contract / empty-message — each a variant with a
  `branched_from`), so the error path is **one extra branch, not N duplicate processes**.

**Root cause**: the `narrow` step **never ran** — the grouping/variant tables were empty (zero
suggestions, zero grouped processes, zero variants). The BA (`document` step) then ran over the
**raw, ungrouped** runs, so it documented un-reconciled input. Re-running the BA cannot fix this: it
operates **downstream** of the missing grouping.

**Why this corrects SQ-7's framing**: the BA's job is to **document a process, not to merge runs**.
"Shouldn't the BA reconcile?" — no; reconciliation is a separate stage that must run first. So
GC-20/GC-21 are real adherence/robustness gaps, but the **primary** failure here is an
**orchestration gap**: the pipeline skipped `narrow`.

**Direction (fix order)**:
1. Run `narrow` — group the raw runs into one `ba_process` per journey with happy-path / each
   validation-error as **variants (branches)**, so the error path is one extra branch.
2. Then run the BA over the **reconciled** processes, each documenting one journey with all its
   states/variants, every step citing its screenshot+wireframe.

**Caveats observed** (for whoever runs it): the grouping suggestions come from the chat orchestrator
service (dashboard proxies to it on its own port) which **must be running**; and grouping **writes
to the store** (a real, revision-reversible mutation). → `04` GC-20/GC-21, `07` D-8, proving-ground
`08` group G.

**Product gaps worth hardening** (so this can't silently recur):
- The `document` step should **refuse or loudly warn** when it runs on a portal whose `narrow` step
  produced zero grouped processes while raw runs exist (a "you skipped narrow" guard) — see D-8.
- The dashboard / pipeline status should make a **skipped `narrow`** visible (not a silent default to
  documenting raw runs).
- **Consequence**: because `document` ran on raw runs, the written docs (`PROC-*`/`UC-*`) are not
  keyed onto the reconciled model (`PRC-*`), so the Processes tab and the Docs section don't line up
  — the two-"processes" confusion in **D-9**.

---

## Priority order (what to fix first for scan quality)

1. **SQ-8 / run `narrow` before the BA** (GC-20/GC-21) — the root cause of the duplicate/thin docs;
   reconcile raw runs into processes-with-variants first, then document. Guard the `document` step
   against un-narrowed input (D-8).
2. **SQ-3 / frontier** (and GC-16/18) — stops the money bleed and the wedged runs; unblocks
   everything.
3. **SQ-4 / content-ready capture** (H-3, GC-13) — stops recording junk evidence.
4. **SQ-2 / duplicate screens** (C-3 + frontier) — cleans the inputs the BA depends on.
5. **03 trace completion** — gives the BA real process evidence.
6. **SQ-6 / BA quality gate** — once inputs are clean and processes exist, raise the bar.
7. **SQ-7 / run selection + citation** (GC-20/GC-21) — downstream of SQ-8: document from the richest
   trace, cite a region per step/state; a data-hygiene pass so good evidence isn't crowded out.
8. **SQ-5 / resume-from-node** — usability for partial re-scans.
9. **SQ-1 / store scatter** — hygiene (C-8/C-9).
