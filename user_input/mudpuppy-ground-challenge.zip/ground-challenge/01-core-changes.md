# 01 — Core crawler changes (fixes & lessons)

Changes made to the crawler core while mapping **Portal-X**. Each entry: the layer/file, what
changed, the real-world cause, and the lesson / upstream recommendation. All are anonymised; none
reference the client. These are the strongest candidates to bring back into MudPuppy proper.

Legend: ✅ = clearly correct, bring upstream as-is · ⚠️ = correct idea, but the fork took a shortcut
that should be done properly upstream.

---

## C-1 ✅ A 403/429 on a background request must not kill the whole run

- **Layer**: `safety/block-detector.ts`, `crawler/request-gate.ts`
- **Change**: `detectBlock()` gained an `isMainDocument` flag. HTTP **403/429 only hard-stops when
  it is the main-frame document navigation** (a real access-denied / rate-limit *page*). A 403/429
  on a background XHR or sub-resource no longer halts the run. The request gate passes
  `isMainFrameDocument(response)`. CAPTCHA / portal-signature markers still block on any status.
- **Cause**: a SPA fired a background data call that returned 403 while the page itself rendered
  fine; the old code treated *any* 403 as a bot wall and stopped the run with zero states.
- **Lesson**: block detection must distinguish the *page* from the *page's chatter*. A modern SPA
  routinely tolerates individual failing XHRs. Default `isMainDocument = true` keeps back-compat.

## C-2 ✅ Anchors (`<a>`/`<area>`) are navigation, not form submits

- **Layer**: `safety/classifier.ts`, `safety/types.ts`, `crawler/action-extractor.ts`,
  `mcp-server/.../actions.ts`, `services/record-transition.ts`
- **Change**: a `tag` field was threaded through the action descriptor. (a) An `a`/`area` tag now
  counts as **positive read evidence** even without an `href`. (b) An **anchor inside a `<form>` no
  longer inherits the form's `method`/`action`.**
- **Cause**: the legacy stack wraps a whole page in one big `<form method="post">`
  (legacy server-rendered, one-big-form style). Every tile/link inside it looked like a non-idempotent POST and was
  classified `mutating`, so a read-only run refused to click navigation tiles — the crawl could not
  move past the dashboard.
- **Lesson**: classification must use the element's own semantics (an anchor navigates on click; it
  does not submit the enclosing form). Without this, the entire family of one-big-form legacy portals is
  unmappable read-only. This single fix unblocks a huge class of legacy sites.

## C-3 ✅ Anchor tiles need a stable **text** locator in a re-rendering SPA

- **Layer**: `crawler/clickables.ts`, `mcp-server/.../act.ts`
- **Change**: for an anchor tile with an unambiguous name, try the **exact-text locator first**,
  then fall back to the DOM path. Non-anchor clickables keep path-first.
- **Cause**: SPA lists re-render and re-key between observe-time and act-time, so a DOM path
  captured earlier was stale by the time `act` ran → `click_failed`.
- **Lesson**: in SPAs the visible text is more stable than the DOM path for links. Choose the
  locator by element kind.

## C-4 ✅ Role-less SPA clickables need a wider actionability budget

- **Layer**: `mcp-server/.../act.ts`
- **Change**: a role-less clickable (an anchor tile) gets a **15 s trial budget**; normal controls
  keep the tight 5 s so the common case stays fast.
- **Cause**: a tile in a re-rendering list took >5 s to settle into an actionable state → spurious
  `click_failed`.
- **Lesson**: one global actionability timeout is wrong; scale it to how dynamic the element is.

## C-5 ✅ `selectOption` must fall back from value to visible label

- **Layer**: `mcp-server/.../act.ts`
- **Change**: `selectOption(value)` now falls back to `selectOption({ label: value })` when the
  bare-value match finds nothing.
- **Cause**: a trace author knows the option's **visible label**, not the server-assigned `value`
  on a legacy `<select>`. The bare value matched nothing and the step failed.
- **Lesson**: accept the human-visible identifier and resolve it; don't force authors to know
  internal option values.

## C-6 ✅ Framework-bound inputs need real input/change/blur events

- **Layer**: `mcp-server/runtime/login.ts` (`enterBound()`)
- **Change**: login fields are filled with `enterBound()` which, after `.fill()`, dispatches
  `input` + `change` and blurs, so a framework-bound model (a reactive, data-bound form with callback-style inputs)
  commits the value. No-op difference for a plain HTML form.
- **Cause**: on the SSO/OAuth identity provider the login inputs are framework-bound; a bare
  `.fill()` set the DOM value but not the model, so submit was rejected and the run never left the
  login page (login outcome `unknown`).
- **Lesson**: `page.fill()` is not enough for data-bound SPA inputs. The login (and trace fill)
  path should always dispatch the events a reactive model listens for.

## C-7 ✅ Non-http(s) hrefs must not reach URL parsing

- **Layer**: `mcp-server/runtime/run-state.ts` (`isHttpUrl()` guard)
- **Change**: `routeTemplateFor()` / `peekRouteTemplate()` return the href unchanged when it is not
  an absolute http(s) URL, instead of throwing deep in `new URL()`.
- **Cause**: a legacy `javascript:` postback "Next" link crashed `act` with
  `ERR_INVALID_URL` — route-template inference assumed every href was a navigable page.
- **Lesson**: never assume an href is a URL. `javascript:`/`mailto:`/relative/garbage hrefs are
  common on legacy pages; guard every URL parse.

## C-8 ⚠️ Unknown environment slug must not silently create a stray store

- **Layer**: `store/src/db.ts` (`KNOWN_ENVIRONMENTS` guard), `store/src/import-agent.ts`
  (`allowUnknown: true` when reading existing files)
- **Change**: `dbPathFor()` rejects an environment slug outside a known set, with a message
  explaining that a typo silently creates a parallel `<name>.sqlite`. Readers that enumerate
  existing files opt out of the guard.
- **Cause**: a stray `PATHFINDER_ENV` value produced a parallel `.sqlite` store that crawl data
  leaked into — a direct cause of the **"scattered scans / data split across stores"** symptom
  (see `05-scan-quality-findings.md`). A stray creds-source store was found beside the real ones.
- **Lesson is right; the fork's execution is the ⚠️**: guarding the slug is correct, but the fork
  **re-hardcoded** the known set (see C-9). The proper upstream fix is a single source of truth for
  environments *and* a declarative "is this production?" flag — not another hardcoded list.

## C-9 ⚠️ Environment enum was re-hardcoded instead of made freeform

- **Layer**: `config/portal-schema.ts`, `config/load-portal.ts`, `vault/store.ts`,
  `store/db-types.ts`, `mcp-server/tools/index.ts`, `mcp-server/services/start-run.ts`,
  `mcp-server/main.ts` + `ba-main.ts` (default `production` → a dev slug)
- **Change (fork)**: the environment enum was changed from `production | staging | sandbox` to a
  **different fixed triple** of client-specific tier names, duplicated across six+ files; the MCP
  default env flipped from `production` to a dev tier.
- **Cause**: the client's dev/acceptance tiers don't fit `staging`/`sandbox`, and a dev host that
  doesn't match the built-in "non-production" hostname regex was wrongly gated as production.
- **Lesson (the issue log already states the correct fix)**: don't swap one hardcoded triple for
  another. Make the environment a **freeform label** with an explicit **`production: true|false`**
  flag per environment; collapse the duplicated enum into one source of truth; key the
  production-address guard off the declared flag (or an explicit host allowlist), not a hostname
  regex. Add **mutation tests** around env/run routing and prod-gating so an inverted or dropped
  branch is caught. → `07-discussion-items.md` D-1, `06-roadmap.md` Phase 1.

## C-10 ✅ A 13th documentation kind: `api_endpoint`, and element behaviour

- **Layer**: `docs-model/schemas/doc-content.ts` + `doc-record.ts`, `docs/render/*`
- **Change**: added an `api_endpoint` record kind (code `API`): `method`, `url_template` (path with
  parameters generalised, e.g. `/api/contracts/{id}`), `purpose`, optional `status_observed`,
  `request_shape`, `response_shape`. `ScreenElement` gained an optional `behaviour` field (what the
  element does, in English). Export/render updated for both.
- **Cause**: the BA could see captured `network_call` shapes but had no record kind to document the
  backend contract behind a screen, and no place to say what a button *does*.
- **Lesson**: the documentation model should let the BA promote an observed network shape into a
  first-class, evidence-linked API record. Good upstream feature; keep `url_template` generalised
  and leave concrete URLs on the evidence (privacy-preserving by design).

---

## Summary table

| # | Area | Severity of problem fixed | Bring upstream? |
| --- | --- | --- | --- |
| C-1 | Block detection scope | High (zero-state runs) | Yes, as-is |
| C-2 | Anchor vs form-POST classification | **Blocker** for one-big-form legacy portals | Yes, as-is |
| C-3 | Anchor text locator in SPA | High (click_failed churn) | Yes, as-is |
| C-4 | Actionability budget for SPA tiles | Medium | Yes, as-is |
| C-5 | selectOption label fallback | Medium | Yes, as-is |
| C-6 | Framework-bound login inputs | **Blocker** for SPA/SSO login | Yes, as-is |
| C-7 | Non-http href guard | High (act crash) | Yes, as-is |
| C-8 | Stray-store guard | High (scattered scans) | Idea yes; pair with C-9 done right |
| C-9 | Freeform environment + prod flag | High (gating + scatter) | Yes, but **do it properly** (not re-hardcode) |
| C-10 | `api_endpoint` kind + element behaviour | Medium (BA depth) | Yes, as-is |
