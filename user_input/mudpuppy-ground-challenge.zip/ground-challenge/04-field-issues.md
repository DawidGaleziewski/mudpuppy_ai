# 04 — Field issues (anonymised)

The issue log from running MudPuppy against Portal-X, grouped and de-identified. Original ids are
replaced with neutral `GC-NN`. Each: symptom → cause → fix/workaround applied → upstream direction.
Status reflects the source log (patched locally / worked around / open).

Severity: 🔴 blocker · 🟠 high · 🟡 medium.

---

## Group A — First start, environment & setup

### GC-01 🟡 Robots compliance is pointless on a private dev tier
- **Symptom**: a dev/acceptance tier served `Disallow: /` (or compliance gate blocked the run) even
  though it's a private, authorised environment.
- **Cause**: compliance/robots gating assumes a public production site.
- **Fix**: `robots: ignore` per portal; declare the tier non-production.
- **Upstream**: tie robots/compliance strictness to the declared `production: false` flag (D-1).

### GC-02 🟠 No first-start "doctor" diagnosis
- **Symptom**: the first run against a new corporate portal failed for environmental reasons (proxy,
  CA, UA, allowlist) with errors that didn't point at the cause.
- **Cause**: no pre-flight that probes the environment and names the fix.
- **Fix**: diagnosed by hand.
- **Upstream**: a **doctor** stage driven by an extensible **registry** (id, applies_when,
  depends_on, probe, signature, fix, inputs); only inputs are site-specific. New checks/fixes add
  without core changes. → `06-roadmap.md` Phase 3.

### GC-03 🟠 Reachable only through a corporate forward proxy
- **Symptom**: all requests failed / 403 until routed through the corporate proxy.
- **Cause**: the site's egress allowlist only admits the proxy's IP; `HTTPS_PROXY` env was **not
  honoured** by the gate's `route.fetch`.
- **Fix**: opt-in `network.proxy { server, bypass, enabled }` in the portal file.
- **Upstream**: first-class, agnostic `network.proxy` support in the request gate (not just env).

### GC-04 🟡 Windows PAC proxy discovery from WSL
- **Symptom**: couldn't discover the right proxy automatically from WSL (Windows PAC file).
- **Fix**: resolved by hand to the known proxy host.
- **Upstream**: optional PAC/`doctor` probe to suggest the proxy (input-only, agnostic).

### GC-05 🟠 IP-allowlist 403 ("not whitelisted")
- **Symptom**: `RUN_STOPPED` HTTP 403, 0 states, before any page.
- **Cause**: same as GC-03 — not going through the allowlisted egress.
- **Fix**: route via `network.proxy`.
- **Upstream**: the doctor's `net.ip-allowlist` check recognises this 403 and points at the proxy.

### GC-06 🟡 Native build toolchain (better-sqlite3) missing
- **Symptom**: install failed building a native module on a locked-down box.
- **Fix**: `--ignore-scripts` workaround.
- **Upstream**: document the prebuilt/`--ignore-scripts` path; doctor `toolchain.native-build`
  check.

### GC-07 🟡 WAF blocks a non-browser User-Agent
- **Symptom**: the identity provider / WAF returned 403 for a crawler-looking UA **before the login
  form rendered** (proven: crawler UA → 403; a real browser UA → normal 302→200 login form).
- **Cause**: a WAF in front of the auth endpoint rejects non-browser UAs.
- **Fix**: set a realistic browser UA in `rate_limit.user_agent` per portal.
- **Upstream**: doctor `waf.user-agent` check; document that some WAFs gate on UA. (⚠️ keep the UA
  in config, never in code; never commit a client's exact UA — see anonymisation note.)

---

### GC-22 🟠 Silent default-env fallback → MCP operates on the wrong environment
> Recorded from a field observation on 2026-10-15 (record-only). An instance of the env-model
> problem in C-9 / D-1 / GC-01, seen operationally.
- **Symptom**: while working on one tier (call it env **B**), the operator kept seeing MCP calls go
  to a *different* tier (env **A**). The dashboard and chat were serving env B, but the MCP servers
  were talking to env A — a persistent, confusing mismatch.
- **Cause**: the MCP config (`mcp.json`) pins `PATHFINDER_ENV` to a **default tier**, and it was
  restored to that default after a session that had temporarily flipped it to env B. Any new agent
  session then spins up the MCP servers on the default (env A) again — a **silent fallback** that
  contradicts the dashboard/chat (env B). The project's own rule ("`PATHFINDER_ENV` in mcp.json must
  match the `--env` you pass") was violated by the default, not by the operator.
  - **Compounded by stray processes**: long-lived MCP server processes from a **different checkout**
    of the product were still running (~1.5 h old), a third `PATHFINDER_ENV` variable in play — so
    which store a call hit depended on which process answered.
  - **No data corruption observed**: store-modification times confirmed the session's
    narrow+document work all landed on env B; env A only held a few stray login-only records from an
    earlier mis-env'd run. But the *risk* of writing to the wrong store was real.
- **Status**: open (observed; not fixed — operator decision pending on config + stray processes).
- **Upstream direction**:
  1. **No silent env fallback.** If `PATHFINDER_ENV` is unset/ambiguous, the MCP server should
     **refuse to start** (or demand an explicit env), not quietly default to a tier — especially now
     that the default is a non-prod client tier (C-9 flipped the default). This is the operational
     half of **D-1** (freeform env + explicit `production` flag) and **C-9** (one source of truth).
  2. **Env agreement check.** On start (and surfaced in the dashboard), assert that the MCP server,
     the dashboard and the chat orchestrator all point at the **same** env; warn loudly on a
     mismatch instead of letting it run.
  3. **Single running instance / lock.** Detect and warn about **stray MCP server processes from
     another checkout** sharing the machine (a PID/lock file per data dir), so a call can't be
     answered by an unrelated server on a different env.
  4. **Make the current env visible** in every MCP result / the dashboard header, so "which env am I
     on?" is never a guess.
- **Cross-refs**: C-8 (stray-store guard — the write-side of the same hazard), C-9 / D-1 (env model),
  GC-01 (dev-tier gating). Proving-ground: `08` group E (`STRAY_ENV_SLUG`) + a new env-mismatch case.

## Group B — Auth, SSO & long redirect chains (the big design topic)

### GC-08 🔴 Login wait vs rate limit (SPA login form renders late)
- **Symptom**: `control_not_found` — the login form appeared only after dozens of chunked requests;
  at the default polite rate (~2 req/s) that exceeded the fixed login timeout, so login gave up.
- **Cause**: fixed timeouts that ignore our own rate limiter; the limiter made the SPA form slow to
  appear.
- **Fix**: opt-in `login.wait { form_ms, success_ms, poll_ms, enabled }` + a faster rate on the dev
  tier.
- **Upstream**: part of D-2 — waits derived from the limiter; separate rate limits for static assets
  vs the main document.

### GC-09 🔴 Auth flows & multi-hop cross-host redirect chains *(the main design topic)*
- **Symptom**: `failed / unknown` and effective lockout even though the user *does* land on the
  dashboard; the success check ran while still on the IdP host mid-redirect.
- **Cause**: four things compound — fixed timeouts ignoring the limiter, a **single-shot** success
  check, **multi-hop cross-host** redirects, and treating **ambiguous = failed = locked out**.
- **Fix**: per-portal `login.success`/`failure` markers (a success URL-not-matching the IdP host; a
  failure error-banner text that is absent on a fresh form), longer waits.
- **Upstream (design)**: → `07-discussion-items.md` **D-2**. Wait on **conditions with a deadline
  that extends while there is progress**; a **`pending`** outcome (not `failed`); budgets derived
  from the limiter; **per-portal transit zones** (hosts/paths where the crawler polls but does not
  record intermediate hops); a recorded navigation chain; **one** wait mechanism shared by login,
  navigate and act.

### GC-10 🟡 Redactor masks the persona id
- **Symptom**: `runs.persona_id` came back `[secret]` because the persona id equalled the login
  name, which the redactor masks.
- **Fix**: renamed the persona so its id differs from the credential.
- **Upstream**: redact credential **values**, not an id that merely matches one; keep the persona id
  readable.

### GC-11 🟡 Identity-provider error page → blank evidence, wrong reason
- **Symptom**: a transient IdP error page (message rendered by script seconds later) produced a
  state with an **empty snapshot and blank screenshot**, and login reported `control_not_found`; the
  next run logged in fine.
- **Cause**: evidence captured before the late-rendered error text; transient error misattributed.
- **Upstream**: wait for the error text to render before capturing; classify a transient IdP error
  distinctly from "control not found"; retry.

---

## Group C — Network, TLS & rendering

### GC-12 🟠 TLS inspection + per-host proxy routing
- **Symptom**: third-party asset hosts failed when forced through the single corporate proxy (they
  got a TLS-inspected cert and 403), while the portal host needs the proxy.
- **Cause**: one proxy for everything is wrong; some hosts must go direct, some via proxy; direct
  traffic is TLS-inspected and needs the corporate CA trusted.
- **Fix**: `network.proxy.bypass` list for asset/CDN hosts + `network.ca_certificates` (trust the
  corporate TLS-inspection CA). (⚠️ never commit the CA paths/contents — anonymisation note.)
- **Upstream**: per-host routing (proxy vs direct) + a CA-trust option; doctor `net.tls-inspection`.

### GC-13 🟠 Unstyled pages / screenshots because a stylesheet was blocked
- **Symptom**: pages and **screenshots recorded unstyled** because the stylesheet loaded from a
  blocked CDN host.
- **Cause**: the proxy refused the third-party CDN; the page half-rendered.
- **Fix**: `network.asset_check { enabled, resource_types, recapture }` + a bypass for the asset
  hosts; emit an `asset_check:failed` warning and `render_warnings` on the state.
- **Upstream**: an **asset-health check** that warns when key assets fail and (optionally)
  **recaptures** the screenshot once assets load — directly relevant to your "screenshots of
  unloaded pages" complaint (see `05`).

---

## Group D — Classification & safety

### GC-14 🟠 German submit labels classified as "read"
- **Symptom**: a read-only persona clicked a German "Send/Submit" link and the server logged a form
  POST — the submit keyword rules were English/Polish only.
- **Fix**: per-portal `action_rules` `submit_request` keywords in German (Senden, Absenden,
  Abschicken, Speichern, Bestätigen, Weiter, Hochladen, Beantragen).
- **Upstream**: ship a multi-locale submit-keyword dictionary (DE at least); make the submit lexicon
  locale-aware, not a hardcoded two-language list.

### GC-15 🟠 `javascript:window.open(...)` link breaks the browser session
- **Symptom**: clicking a popup/chat link (`href="javascript:…window.open(…)"`) returned `INTERNAL`,
  the item was handed out again, and `finish_run` refused with `FRONTIER_NOT_EMPTY` (stuck run).
- **Cause**: a `javascript:` popup href is neither navigable nor safe; it wasn't caught by a
  `path:` rule (those aren't checked for `javascript:` hrefs).
- **Fix**: `action_rules: [{ id: js-popup, class: external-side-effect, paths: ["**window.open(**"] }]`
  + `denylist: [js-popup]`.
- **Upstream**: recognise `javascript:` hrefs as non-navigable by default; let a frontier item be
  **retired** (not re-handed) when it can't be acted on, so the run isn't wedged (links to GC-19).

---

## Group E — Cost & frontier efficiency

### GC-16 🟠 Mapping cost dominated by refusal churn
- **Symptom**: ~60 credits for one small logged-in map. In one run **148 of 165 crawler turns** were
  a `click_failed` refusal + a `get_next_frontier_item`; **45%** of a day's tool calls were in runs
  that never completed.
- **Cause**: the server handed out hidden/unclickable items; refusal results didn't carry `next`; no
  server-side batching; shared nav actions weren't de-duplicated.
- **Upstream (high value)**: **don't issue hidden/unclickable items**; put `next` in refusal
  results; **server-side batch drain** for read-only map runs; **dedup shared nav actions** across
  states; show **cost per run** in the dashboard (populate `agent_turns`). → `05` and `06` Phase 4.

### GC-17 🟡 Credential bulk import
- **Symptom**: no convenient way to import many personas' credentials at once.
- **Status**: open.
- **Upstream**: a bulk `vault` import path (file of refs → encrypted store), no plaintext on argv.

### GC-18 🔴 Resumed run wedged in `running` (`FRONTIER_NOT_EMPTY`)
- **Symptom**: several runs stuck in `running`; `finish_run` refused because the frontier never
  emptied (fed by GC-15-type unactionable items and hidden items from GC-16).
- **Upstream**: a frontier item that cannot be acted on must be **recorded and retired**, not
  re-queued forever; `finish_run` should be able to complete with a documented remainder.

### GC-19 🟠 Collapsed content not expanded (see also H-2)
- **Symptom**: recorded states missing the links/fields that lived inside closed accordions.
- **Fix**: the `expand_toggles` hook/config (H-2).
- **Upstream**: ship `expand_toggles` as declarative config with the hidden-only + submit-suppress
  rules.

---

## Group F — BA evidence selection & citation

> Recorded from a field diagnosis on 2026-10-15 (not yet reproduced/fixed). Captures *why* a
> documented portal came out thin even though rich evidence existed.

### GC-20 🟠 BA skips interrupted-but-rich trace runs ("completed-only" rule)
- **Symptom**: for a traced form process, the documentation was thin (a process shown with "only one
  step", or only the last-step screenshot) even though a trace run with far more steps/screenshots
  existed. The richest runs were **interrupted**; the thinner **completed/abandoned** runs got
  documented instead.
- **Cause**: the BA practice says *"use every **completed** run"* and chooses runs as "all completed
  map runs, plus trace runs". An **interrupted** trace run — which can hold the most steps and
  screenshots (the run was cut off *after* doing the richest work) — is skipped by rule. A
  `goal_reached` 6-step run wins over an interrupted 12-step run with 8 screenshots.
- **Status**: open.
- **Upstream direction**: run selection should be driven by **evidence richness and outcome
  honesty**, not a blunt status filter. Options: (a) let the BA read interrupted trace runs and
  document their observed steps with an honest `observed_extent` (`until_boundary`/partial); (b)
  surface per-run step/screenshot counts in `list_runs` so the BA (and a human) can pick the richest
  trace per process; (c) a data-hygiene pass that marks a good interrupted run usable, or de-dups the
  thin/duplicate variant runs so they don't crowd out the rich one. Pairs with SQ-2 (duplicates) and
  SQ-7. → `05` SQ-7, `06` Phase 5, `07` D-4.

### GC-21 🟠 BA under-cites screen regions (one per record, not one per step/state)
- **Symptom**: a multi-step process / multi-state screen showed **one** screenshot+wireframe for the
  whole record; most steps and both validation-error states had no visible evidence, so the pages
  looked empty despite the data being captured.
- **Cause**: the BA cited a single `screen_region` per record. The practice already says to cite the
  touched control's region *per step* and each variant state (happy-path + each validation-error),
  but the model under-applied it, and nothing enforced "one region per step/state".
- **Status**: open (guidance exists; adherence + enforcement do not).
- **Upstream direction**: make it checkable — a **documentation quality check** that flags a
  `use_case`/`process` whose steps or variant states lack a cited `screen_region`, and a BA guidance
  tightening ("cite one screen_region per step and per variant state, not one per record"). This is
  the citation half of the SQ-6 quality gate. → `05` SQ-6/SQ-7, `06` Phase 5, `07` D-4.

## Cross-cutting themes

1. **Corporate environment is the hard part** (A+C): proxy, allowlist, TLS inspection, WAF-UA — a
   **doctor** + agnostic `network.*` config removes most first-day pain.
2. **Auth is a design problem, not a timeout tweak** (B): condition-based waits, a `pending`
   outcome, transit zones, one wait mechanism (D-2).
3. **The frontier wastes money** (E): hidden/unactionable items cause refusal churn and wedged
   runs; fix issuance + retirement + batching + dedup.
4. **Content is often hidden or late** (H-1/H-2/H-3, GC-13/GC-19): seed, reveal, await before
   observing — and recapture when assets fail.
