# 02 — Hook patterns (anonymised)

Portal **hooks** are the owner's trusted code that runs at crawl lifecycle points (the crawler never
writes them). On Portal-X four hooks were needed. They are reproduced here as **de-identified
patterns** — the client's selectors, cookie names, hostnames and URL fragments are replaced with
generic placeholders. The *technique* is the deliverable, not the client's DOM.

Lifecycle points used: `onPageLoad` (after a page settles, before it is observed) and
`onBeforeClickAction` (before the crawler clicks an action).

---

## H-1 — Pre-run cookie to unlock hidden content

**Problem class**: a portal hides part of its content unless a specific cookie is present on the
portal host (a feature flag the client sets manually in the browser console). Without it the page
renders an empty "nothing to show" state and the crawl records a hollow screen.

**Pattern** (`onPageLoad`): on each page load, if the flag cookie is absent, add it, then continue.
Set it on *every* page load because the authenticated pages read it after login; skip when already
present.

```ts
export const setFeatureCookie: Hook<'onPageLoad'> = async (ctx) => {
  const present = (await ctx.cookies.get()).some((c) => c.name === '<FLAG_COOKIE>');
  if (present) return;
  // the browser driver wants url XOR domain+path — pass only `url` and let it derive host + "/".
  await ctx.cookies.add([{ name: '<FLAG_COOKIE>', value: '<VALUE>', url: ctx.config.base_url }]);
  ctx.log('feature cookie set on the portal host (post-login page load)');
};
```

**Lessons**: (1) content can be gated on client-side state the crawler must seed. (2) the browser driver's
`cookies.add` rejects `url` together with `domain`+`path` ("Cookie should have either url or path");
pass only `url`. (3) Upstream, this is better as a declarative `cookies:` list in the portal file
(the issue log shipped exactly that), with the hook form as the escape hatch.

---

## H-2 — Expand collapsed content before observing

**Problem class**: important links/fields live inside collapsed accordions, native `<details>`, and
"show more" toggles. The recorded snapshot (and screenshot) misses them entirely, so the BA never
sees the services on a page.

**Pattern** (`onPageLoad`, runs in-page): open everything collapsed, then restore. Covers four
shapes — native `<details>:not([open])`, `aria-expanded="false"` toggles, section-header links
(`dl dt > a[href="#"]`), and "show more" controls — with four safety rails:

1. **Suppress programmatic form submits** while expanding (override `HTMLFormElement.prototype`
   `submit`/`requestSubmit` to no-ops, restore after) so a toggle inside the page-wide form cannot
   post the page away.
2. **Never click** real off-page links, submit buttons, comboboxes/popup openers, or disabled
   controls.
3. **Only click a toggle whose panel is actually hidden.** Clicking an *already-open* section
   header *collapses* it — observed to drop a page's service links from ~20 to ~2. Decide
   open/closed from the controlled region's visibility (`hidden`, `aria-hidden`, `display:none`,
   `visibility:hidden`, `offsetParent === null`).
4. **Cap** the number of expansions (e.g. 60) so a pathological page can't loop.

```ts
export const expandCollapsed: Hook<'onPageLoad'> = async (ctx) => {
  const opened = await ctx.inPage(() => {
    const proto = HTMLFormElement.prototype;
    const origSubmit = proto.submit, origReq = proto.requestSubmit;
    proto.submit = function () {}; proto.requestSubmit = function () {};
    let count = 0; const MAX = 60;
    // 1) native <details>; 2) aria-expanded="false"; 3) dl>dt>a[href="#"]; 4) "show more"
    //    … click only when the controlled region is genuinely hidden …
    proto.submit = origSubmit; proto.requestSubmit = origReq;
    return count;
  });
  if (opened > 0) ctx.log(`expanded ${opened} collapsed section(s)`);
};
```

**Lessons**: this is the fix for the **"screenshots/snapshots of a page with its content still
hidden"** symptom. The non-obvious bug was #3 — a naive "click every toggle" *hides* content that
was open by default. Upstream this became a declarative `expand_toggles:` config (enabled, paths,
selectors, exclude, max) with the same submit-suppression and hidden-only rule.

---

## H-3 — Wait for a late-mounting micro-frontend before clicking

**Problem class**: a service form's body is rendered by a **micro-frontend that mounts *after* the
shell page settles**. The crawler's click arrives before the form exists, so it clicks into nothing.

**Pattern** (`onBeforeClickAction`): on the pages that host the micro-frontend, tell the server to
wait for the mount point to be filled before the click. Harmless elsewhere (brief wait, then
proceed).

```ts
export const waitForLateForm: Hook<'onBeforeClickAction'> = (ctx) => {
  if (/<SERVICE_PAGE_PATH_PATTERN>/i.test(ctx.url)) {
    return { waitFor: '[data-mfe-mount] :not(:empty), .mfe-root form, main form' };
  }
  return undefined;
};
```

**Lessons**: "page settled" (network idle / load) is **not** "content ready" when a micro-frontend
mounts late. A per-page, condition-based wait before acting fixes it. This connects to the broader
**"one wait mechanism that waits on conditions with a deadline"** design item (`07`, D-2).

---

## H-4 — Classify SPA vs legacy server-rendered pages (read-only)

**Problem class**: the portal mixes a modern SPA shell with legacy server-rendered pages; the team
wants each recorded state tagged as "new SPA" or "legacy" (migration candidate).

**Pattern** (`onPageLoad`, read-only, in-page): the reliable positive signal is the SPA's mount
container; its absence on a portal page means legacy. Corroborate with generic framework
fingerprints and log a verdict into the state's decision log.

```ts
export const detectStack: Hook<'onPageLoad'> = async (ctx) => {
  const r = await ctx.inPage(() => {
    const spa = document.querySelector('<SPA_MOUNT_SELECTOR>') !== null;
    const signals = [];
    // generic, non-client fingerprints only (placeholders — fill with the stack's own markers):
    if (document.querySelector('<LEGACY_SERVER_STATE_FIELD>'))
      signals.push('legacy:server-rendered page stack');
    // (plus generic CMS url/marker checks)
    return { spa, signals, title: (document.title || '').slice(0, 80) };
  });
  ctx.log(r.spa ? `stack:spa present` : `stack:legacy ${r.signals.join('; ')}`);
};
```

**Lessons**: a cheap read-only hook can turn a crawl into a **migration inventory** (which pages are
still legacy). A legacy server-rendered stack exposes a reliable hidden server-state field you can
use as a marker (describe the behaviour; don't hard-name the framework). This pairs with C-2
(one-big-form classification) — knowing a page is legacy explains why the anchor-vs-form
fix matters there.

---

## ⚠️ The `esbuild`/`tsx` `__name` in-page gotcha (applies to every in-page hook)

Any function passed to `ctx.inPage(fn)` is serialised and evaluated **in the page**. When the server
runs under `tsx`, esbuild's transform injects `__name(...)` wrappers around **named** functions/
arrows. `__name` does not exist in the page → `ReferenceError: __name is not defined` and the hook
throws.

**Rule**: the in-page function body must be **flat** — no named inner helpers, no const-bound arrows
that esbuild annotates. Only anonymous expressions. (Overriding prototype methods with anonymous
`function () {}` is fine.) This cost real debugging time; it belongs in the hook-authoring docs.

**Upstream direction**: either a documented `NAME_SHIM` that defines `__name` in the page before an
in-page eval, or a build step that strips the annotation for hook bodies — so hook authors don't
have to hand-flatten every function.

---

## Takeaways for the hooks system

- The four hooks map to a general need: **seed state** (cookie), **reveal state** (expand),
  **await state** (late mount), **observe state** (classify). A mature hooks API should make all
  four easy and safe (submit-suppression, hidden-only clicks, read-only guarantees).
- Prefer **declarative config** for the common cases (cookies, expand-toggles) with hooks as the
  escape hatch for the bespoke 10%.
- Document the `__name` gotcha prominently; it will bite every in-page hook author.
