# ground-challenge

Lessons learned, fixes and open problems gathered from running MudPuppy against a **real,
corporate, login-gated legacy insurer portal** (anonymised throughout as **Portal-X**). The source
material is a downstream fork of MudPuppy that was patched live during a client engagement, plus a
separate issue log. This folder keeps only the **solutions, patterns and lessons** — no portal
names, URLs, hostnames, credentials, personas, CA paths or recorded evidence.

> Anonymisation contract: no real portal name, no hostnames/URLs, no proxy address, no CA-cert
> paths, no User-Agent strings, no persona names, no credentials, and no copied evidence
> (screenshots, snapshots, `.sqlite` stores). See [`anonymization-note.md`](anonymization-note.md).
> Real-world artefacts are referred to generically: **Portal-X** (the legacy insurer portal), the
> **SSO/OAuth identity provider**, the **corporate proxy**, the **TLS-inspection CA**.

## What is here

| File | What it holds |
| --- | --- |
| [`01-core-changes.md`](01-core-changes.md) | Every change made to the crawler core (safety, crawler, mcp-server, store, config, docs-model), with the real-world cause and the lesson. Candidates to upstream. |
| [`02-hook-patterns.md`](02-hook-patterns.md) | The portal-hook solutions (pre-run cookie, expand collapsed content, wait for a late micro-frontend, SPA-vs-legacy detection) as reusable, de-identified patterns — including the `esbuild/tsx __name` in-page gotcha. |
| [`03-trace-driver-pattern.md`](03-trace-driver-pattern.md) | The **force-a-form-to-completion** pattern: `mode:"trace"` drivers + per-portal `traces.yaml` with happy-path / validation-error / loading variants. Directly addresses "I can't make the scanner finish a form process". |
| [`04-field-issues.md`](04-field-issues.md) | The 19 field issues from the issue log, anonymised and grouped (first-start/environment, auth & redirect chains, network/TLS, classification, cost/frontier). Each with symptom → cause → fix/workaround → upstream direction. |
| [`05-scan-quality-findings.md`](05-scan-quality-findings.md) | The scan-quality problems you observed (scattered stores, duplicate screens, frontier not advancing, screenshots of unloaded pages, re-scanning instead of pushing the frontier, "scan from a graph point starts fresh", thin BA docs) — each tied to concrete evidence and a root cause. |
| [`06-roadmap.md`](06-roadmap.md) | A detailed, phased roadmap turning all of the above into upstream work, with priorities and acceptance criteria. |
| [`07-discussion-items.md`](07-discussion-items.md) | Open design questions that need a decision before building (env model, auth/transit zones, cost model, BA quality bar). |
| [`08-proving-ground-candidates.md`](08-proving-ground-candidates.md) | Concrete, disposable scenarios to add to `apps/proving-ground` so each lesson is reproducible locally without the real site. Maps every issue to a switch. |
| [`anonymization-note.md`](anonymization-note.md) | The scrubbing rules and the term-substitution table used here. |

## How to read it

- Want to **harden the product**? Start with `01-core-changes.md` and `06-roadmap.md`.
- Want to **reproduce a problem locally**? `08-proving-ground-candidates.md`.
- Want the **field war-stories**? `04-field-issues.md` and `05-scan-quality-findings.md`.

This folder is produced by the `ground-challenge` skill (`.kiro/skills/ground-challenge/`), which
re-runs the analysis over the source repos and regenerates these documents anonymised.
