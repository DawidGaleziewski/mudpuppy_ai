# 07 — Discussion items (decide before building)

Open design questions raised by the field work. Each needs a decision before the matching roadmap
phase starts. Framed as a question with options and a recommendation.

---

## D-1 — Environment model: enum, freeform, or hybrid?

**Context**: the enum `production | staging | sandbox` didn't fit the client's tiers; the fork
re-hardcoded a different triple across six+ files (C-9). The production-address guard uses a
**hostname regex** of known non-prod labels, which mis-gated a dev host.

**Question**: how should an environment be declared and how should "is this production?" be decided?

- **Option A — keep an enum, add client tiers.** Simple, but every client needs a code change; the
  scatter/duplication stays.
- **Option B — freeform label + explicit `production: true|false` per env** (the issue log's
  recommendation). The guard keys off the declared flag (plus optional explicit host allowlist), not
  a regex. One source of truth; add a tier with config only.
- **Option C — hybrid**: freeform label, but a small reserved set (`production`) still forces the
  strict gate regardless of the flag, so you can't accidentally flag prod as non-prod.

**Recommendation**: **B with C's safety rail** — freeform + `production` flag, but a
production-looking address *and* `production:false` triggers a loud confirmation, not a silent pass.
Add mutation tests on the gating. → Roadmap Phase 1.

---

## D-2 — Auth & long redirect chains: how do we wait and when is login "done"?

**Context**: the biggest field pain. Fixed timeouts that ignore the limiter, single-shot success
checks, multi-hop cross-host redirects, and "ambiguous = failed = lockout" (GC-08/09/11).

**Questions**:
1. **Wait model** — one wait mechanism for login/navigate/act, waiting on **conditions** with a
   deadline that **extends while there is progress**? vs per-operation fixed timeouts.
2. **Outcome model** — introduce a **`pending`** outcome distinct from `failed`, so an in-progress
   chain isn't a lockout?
3. **Transit zones** — per-portal hosts/paths where the crawler **polls but does not record**
   intermediate hops (the IdP hops), recording only the landing?
4. **Rate limits** — separate budgets for the main document vs static assets vs third parties, since
   the polite rate starved the SPA login form?

**Recommendation**: design one **condition+deadline** wait, add **`pending`**, define **transit
zones** in the portal file, and split the rate limit by request class. This is a spec on its own.
→ Roadmap Phase 5. Decide early because it touches login, navigate and act.

---

## D-3 — Hooks vs declarative config: where is the line?

**Context**: the fork implemented pre-run cookie, expand-collapsed, late-mount wait and stack
detection as **hooks**; the issue log shipped some as **declarative config** (`cookies:`,
`expand_toggles:`, `login.wait`, `network.*`).

**Question**: which obstacles are declarative config (owner fills fields) and which stay as hooks
(owner writes code)?

- **Config** fits the **common, parameterisable** cases: seed cookies, expand toggles, waits,
  proxy/CA/asset-check.
- **Hooks** fit the **bespoke 10%**: a page-specific classifier, an unusual DOM dance.

**Recommendation**: ship the common four as declarative config with hooks as the escape hatch.
Define a small, stable hook API (lifecycle points, `inPage`, `cookies`, `log`, `waitFor`) and
**document the `__name`/esbuild in-page gotcha** (or add a `NAME_SHIM`). → Phase 5.

---

## D-4 — What is the BA "quality bar", and should it gate?

**Context**: documentation was thin — screens recorded twice, no requirements/business rules
(SQ-6).

**Questions**:
1. What is the **minimum** for a documented portal? (e.g. every capability has ≥1 requirement; every
   form process has a use-case with main + exception flows; validation messages become business
   rules.)
2. Should a **quality gate** *fail* an export below the bar, or just *flag* it?
3. How much is **input quality** (dedup screens, process evidence) vs **BA guidance**?

**Recommendation**: fix inputs first (Phase 4), feed process evidence (Phase 2), then add a
**flagging** gate (not hard-fail) that lists gaps: screens without requirements, duplicate screens
sharing a route template, processes without exception flows. Promote to hard-fail once stable.
→ Phase 5.

---

## D-5 — "Scan from a point": resume-mapping semantics

**Context**: `focus.start_url` exists, but a focused **map** re-discovers the subtree fresh and
`focus.only_paths` fences out login hops (SQ-5).

**Questions**:
1. Should a focused map **attach to the existing graph** — seed the frontier from a chosen state's
   unexplored outgoing actions and reuse recorded states by fingerprint — rather than start a new
   state set?
2. How does `focus.only_paths` interact with a login redirect that must leave the allowed paths?
   (Auto-allow the login/transit hosts? A separate `auth_paths`?)

**Recommendation**: add an explicit **resume-from-node** map mode (reuse states by fingerprint,
expand only the chosen node's unexplored frontier) and auto-exempt the portal's login/transit zone
from `only_paths`. Document the interaction. → Phase 4 + D-2.

---

## D-6 — Cost model: how do we make a map cheap and visible?

**Context**: ~60 credits per small map; 45% of a day's calls in runs that never finished (GC-16).

**Questions**: server-side batch drain for read-only maps? Never issue hidden items? Dedup shared
nav? Surface **cost per run** (`agent_turns`) in the dashboard with a budget alert?

**Recommendation**: all of the above (Phase 4). Treat "turns per new state" as a tracked quality
metric with a target, measured on a proving-ground gate.

---

## D-7 — Downstream fork → upstream flow

**Context**: the client work lives in a fork that is **regenerated on every update**, so local
patches are overwritten; the issue log explicitly says "don't fix here, write an issue".

**Question**: how do field fixes flow back without leaking client data?

**Recommendation**: this `ground-challenge` folder + the skill (`.kiro/skills/ground-challenge/`) is
the mechanism — extract anonymised lessons on each engagement, land them upstream behind
declarative config + proving-ground gates, so the next fork needs **zero** local patches (only
config + hooks). Make "no local core patches, only config/hooks" the success criterion for the env.


---

## D-8 — Enforce `narrow` before `document`: who owns reconciliation, and should the BA refuse un-narrowed input?

**Context** (recorded 2026-10-15, see `05` SQ-8): the pipeline is **scan → map → narrow → document →
amend**. **Reconciliation is the `narrow` step, owned by the chat orchestrator** (it suggests
groupings; accepting one creates a `ba_process` with happy-path/validation variants as *branches*).
On the engagement, `narrow` was **skipped** (zero grouping suggestions / grouped processes /
variants), so the BA documented **raw, ungrouped** runs → duplicate, thin, one-step process docs.
The BA is **not** supposed to merge runs; it documents a process.

**Questions**:
1. Should the `document` step **hard-refuse** (or loudly warn) when raw trace runs exist but
   `narrow` produced **zero** grouped processes — i.e. detect "you skipped narrow" instead of
   silently documenting raw runs?
2. Should `narrow` be **auto-run** (or auto-suggested) as part of the standard flow, so a human only
   *reviews/accepts* groupings rather than having to remember to invoke it?
3. Where is the boundary of responsibility — does the BA ever get a **limited reconciliation** (e.g.
   "these N runs are obviously one process") as a fallback when `narrow` was skipped, or is that
   strictly the orchestrator's job to keep the BA simple?
4. The orchestrator service must be **running** for grouping, and grouping is a **store mutation**
   (revision-reversible). How is that surfaced/guarded in an automated run so it isn't a silent
   prerequisite?

**Recommendation (to decide)**: keep reconciliation in `narrow` (don't bloat the BA), but add a
**pipeline guard**: `document` warns/blocks on un-narrowed input, and the dashboard shows a skipped
`narrow` plainly. Prefer auto-suggesting groupings so the human step is accept/adjust, not invoke.
Treat the BA's "limited fallback reconciliation" as a non-goal unless the guard proves insufficient.
→ `05` SQ-8, `04` GC-20/GC-21, `06` Phase 5, proving-ground `08` group G.


---

## D-9 — Two layers both called "processes": name collision + no cross-link between the model and the docs

**Context** (recorded 2026-10-15, confirmed in the fork's dashboard code + schema): the product shows
"processes" in two different places that represent **different pipeline layers**, which is genuinely
confusing:

- **Processes tab** (top nav) reads `ba_processes` + `process_variants` — the **reconciled model**,
  the output of the `narrow` step (keys `PRC-nnn`). It shows the journeys-with-variants (A = as-is,
  B/C = to-be), grouping suggestions, loose un-grouped screens, a stage, and lets you compare/draw/
  version. Mental model: *"the canonical list of business processes and their variants — the
  model."*
- **Docs → "Processes and use cases"** reads `doc_records` of kind `process` (key `PROC-nnn`) and
  `use_case` (key `UC-nnn`) — the **written SRS**, the output of the BA `document` step, tracing back
  to the raw `processes`/`process_steps` trace runs. It shows the written records with evidence,
  screenshots, revisions, review state. Mental model: *"the written documentation of those journeys
  — the deliverable."*

**Why they look so different right now**:
1. **Different source tables + key schemes** — `PRC-*` (model, from `narrow`) vs `PROC-*`/`UC-*`
   (docs, from the BA). Same journeys, two id systems, two stores.
2. **Populated by different steps at different times** — on this engagement the BA wrote `PROC-*`
   from raw trace runs **before** reconciliation (SQ-8), while `PRC-*` came from a later `narrow`;
   they describe the same journeys but were never re-keyed 1:1.
3. **Different purpose per page** — the Docs section pairs a process with its use-case (step
   narrative + flows); the Processes tab shows the variant/stage model + diagram. Even for the same
   journey, one is a step-by-step spec and the other a variant model.

**The loose end**: the reconciled `PRC-*` and the documented `PROC-*`/`UC-*` are **not cross-linked**
— nothing wires "this doc describes that modelled process" 1:1.

**Questions**:
1. Is the two-layer split (model vs documentation) the right architecture, and if so, should the UI
   **stop calling both "processes"** — rename one (e.g. Processes tab → "Process model" /
   "Journeys"; Docs → "Process documentation") so the name collision goes away?
2. Should a `doc_record` process/use-case carry a **reference to its `ba_process`** (and vice versa),
   so the two tabs line up 1:1 and you can navigate model ↔ docs?
3. Should the pipeline **order enforce** that documentation is keyed onto the reconciled model
   (document only runs over `ba_processes`, so `PROC-*` always maps to a `PRC-*`)? This ties to
   SQ-8/D-8 — if `document` always runs after `narrow` on the grouped model, the mismatch can't
   arise.

**Recommendation (to decide)**: keep the two layers (model vs SRS is a sound separation) but (a)
**rename in the UI** so they aren't both "processes", (b) add a **1:1 cross-link** (`doc_record` ↔
`ba_process`) surfaced on both pages, and (c) make `document` run over the reconciled model so the
keys always correspond. → `05` SQ-8, `07` D-8, `04` GC-20/GC-21.

> Note: a fix was offered on the engagement (have the BA re-key its process docs onto the reconciled
> `ba_processes` so the tabs line up). Recorded as the operational remedy; the **product** fix is
> (a)+(b)+(c) above so it doesn't recur. Record-only — not applied.